const rewards = {
  exp: 1500,
  money: 3999,
  potion: 9,
}
const cooldown = 604800000 // 7 hari

let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender]
  let now = new Date() * 1

  if (now - user.lastweekly < cooldown) {
    let remaining = user.lastweekly + cooldown - now
    throw `You have already claimed this weekly claim! Wait for *${msToTime(remaining)}*`
  }

  let text = ''
  for (let reward of Object.keys(rewards)) {
    if (!(reward in user)) continue
    user[reward] += rewards[reward]
    text += `*+${rewards[reward]}* ${global.rpg.emoticon(reward)}${reward}\n`
  }

  conn.reply(m.chat, `WEEKLY\n${text.trim()}`, m)
  user.lastweekly = now
}

function msToTime(ms) {
  let seconds = Math.floor((ms / 1000) % 60)
  let minutes = Math.floor((ms / (1000 * 60)) % 60)
  let hours = Math.floor((ms / (1000 * 60 * 60)) % 24)
  let days = Math.floor(ms / (1000 * 60 * 60 * 24))
  return `${days}d ${hours}h ${minutes}m ${seconds}s`
}

handler.help = ['weekly']
handler.tags = ['rpg']
handler.command = /^(weekly)$/i

handler.cooldown = cooldown

module.exports = handler