const hydra = require("@kelvdra/scraper")

const handler = async (m, { conn, text }) => {
  if (!text) return m.reply('Mana link TikTok-nya?');

  await m.reply('Tunggu sebentar, lagi ngunduh...');
  let result;
  try {
    result = await hydra.ttdl(text);
  } catch (e) {
    console.error(e);
    return m.react('❌');
  }

  if (!result) return m.react('❌');
  
  const caption = `*${result.title ?? "-"}*\n\n` +
            `*⌬ Region* : ${result.region ?? "-"}\n` +
            `*⌬ Duration* : ${result.duration ?? "-"}\n` +
            `*⌬ Taken* : ${result.taken_at ?? "-"}\n\n` +
            `*📊 Statistik* :\n` +
            `- 👀 Views: ${result.stats?.views ?? "-"}\n` +
            `- ❤️ Likes: ${result.stats?.likes ?? "-"}\n` +
            `- 💬 Comments: ${result.stats?.comment ?? "-"}\n` +
            `- 🔄 Shares: ${result.stats?.share ?? "-"}\n` +
            `- 📥 Downloads: ${result.stats?.download ?? "-"}\n\n` +
            `*👤 Author* :\n` +
            `- ✨ Nickname: ${result.author?.nickname ?? "-"}\n\n`;

  const videoLink = result.video.find(v => v.type.includes('mp4'))?.url;
  const audioLink = result.music_info.url;
  const photoLinks = result.photos;

  if (videoLink) {
    await conn.sendMessage(m.chat, {
      video: { url: videoLink },
      caption: caption
    }, { quoted: m });
  } else if (photoLinks.length) {
   m.reply(result.title)
    const slideImages = photoLinks.map(photo => ({
      image: { url: photo.url },
      caption: ""
    }));

    if (slideImages.length > 1) {
      await conn.sendAlbumMessage(m.chat, slideImages, { quoted: m, delay: 2000 });
    } else if (slideImages.length === 1) {
      await conn.sendMessage(m.chat, slideImages[0], { quoted: m });
    }
  } else {
    return m.react('❌');
  }

  if (audioLink) {
    await conn.sendMessage(m.chat, {
      audio: { url: audioLink },
      mimetype: 'audio/mp4'
    }, { quoted: m });
  }
};

handler.help = ['tiktok', 'ttimg'].map(v => v + ' <url atau reply>');
handler.tags = ['downloader'];
handler.command = /^(tiktok|tt|ttslide|ttimg)$/i;
handler.limit = 5;
handler.register = true;

module.exports = handler;