const didyoumean = require('didyoumean');
const similarity = require('similarity');
const { generateWAMessageFromContent, prepareWAMessageMedia, proto } = require('@kelvdra/bails');

let handler = m => m;

handler.before = async function (m, { match, usedPrefix, command, conn, text, args }) {
  // Cek apakah bot diban di grup
  if (m.isGroup && global.db.data.chats[m.chat]?.isBanned) return;

  if ((usedPrefix = (match[0] || '')[0])) {
    let noPrefix = m.text.replace(usedPrefix, '').trim();
    let alias = Object.values(global.features).filter(v => v.help && !v.disabled).map(v => v.help).flat(1);
    let mean = didyoumean(noPrefix, alias);
    let sim = similarity(noPrefix, mean);
    let similarityPercentage = parseInt(sim * 100);

    if (mean && noPrefix.toLowerCase() !== mean.toLowerCase()) {
      let response = `• ᴀᴘᴀᴋᴀʜ ᴋᴀᴍᴜ ᴍᴇɴᴄᴀʀɪ ᴍᴇɴᴜ ʙᴇʀɪᴋᴜᴛ ɪɴɪ?\n\n◦ ɴᴀᴍᴀ ᴄᴏᴍᴍᴀɴᴅ: ➠ *${usedPrefix + mean}*\n◦ ʜᴀsɪʟ ᴋᴇᴍɪʀɪᴘᴀɴ: ➠ *${similarityPercentage}%*`;

      let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.create({
              body: proto.Message.InteractiveMessage.Body.create({
                text: response,
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
                text: ""
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: false,
                ...(await prepareWAMessageMedia(
                  { image: { url: logo.thumb } },
                  { upload: conn.waUploadToServer },
                )),
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: `{\"display_text\":\"${mean} \",\"id\":\"${usedPrefix + mean}"}`
                  },
                ],
              })
            })
          }
        }
      }, { quoted: m });

      await conn.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
      });
    }
  }
};

module.exports = handler