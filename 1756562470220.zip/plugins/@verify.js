const { createHash } = require('crypto')

const handler = async (m, { conn }) => {
    let user = global.db.data.users[m.sender]
    if (user.registered) throw '⚠️ Kamu sudah terdaftar!\nUntuk daftar ulang, ketik *unreg*'

    user.registered = true
    let sn = createHash('md5').update(m.sender).digest('hex')

    let verifyingText = [
        "⏳ Verifying [█▒▒▒▒▒▒▒▒▒] 10%",
        "⏳ Verifying [███▒▒▒▒▒▒▒] 30%",
        "⏳ Verifying [█████▒▒▒▒▒] 50%",
        "⏳ Verifying [███████▒▒▒] 70%",
        "⏳ Verifying [██████████] 100%"
    ]

    let lll = await conn.sendMessage(m.chat, { text: '⏳ Sedang memverifikasi...' }, { quoted: m });
    
    for (let i = 0; i < verifyingText.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 800));
        await conn.relayMessage(m.chat, {
            protocolMessage: {
                key: lll.key,
                type: 14,
                editedMessage: { conversation: verifyingText[i] }
            }
        }, {});
    }
    
    await new Promise(resolve => setTimeout(resolve, 500));
    await conn.sendMessage(m.chat, { delete: lll.key });
    
    const buttons = [
        { buttonId: '.menu', buttonText: { displayText: 'MENU' }, type: 1 },
        { buttonId: '.owner', buttonText: { displayText: 'OWNER' }, type: 1 }
    ];
    
    const buttonsMessage = {
        text: `✅ *VERIFIED!* 🎉\n\n🎯 *Selamat! Pendaftaran berhasil.*\n🔖 Serial Number (SN): *${sn}*\n\n📌 Klik tombol di bawah untuk melihat menu.`,
        footer: "Elaina Kawai",
        buttons: buttons,
        viewOnce: true,
        headerType: 4
    };

    await conn.sendMessage(m.chat, buttonsMessage, { quoted: m });
}

handler.help = ['@verify']
handler.tags = ['main']
handler.customPrefix = /^@verify$/i
handler.command = new RegExp

module.exports = handler