/**
 * By: Hydra
 * 𝘵𝘦𝘭𝘦: https://t.me/draa82
 * 𝘪𝘯𝘧𝘰: https://s.id/Genzo82
 * 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VadrgqYKbYMHyMERXt0e
 * 🚨Di Larang Menghapus Wm Ini🚨
 * #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁
 jika script mu gada batas comand, hapus saja itu handler.comand
**/

const ytdl = require("@kelvdra/scraper"); 

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    let [Url, quality] = text.split(' ');

    if (!Url) {
        return conn.reply(m.chat, `Gunakan format: ${usedPrefix}${command} <url> [resolusi]`, m);
    }
       
       let Quality = quality || 'mp3';
       let data = await ytdl.ytmp3(Url, Quality);
			try {	
			conn.sendMessage(m.chat, { react: { text: '⏱️', key: m.key } });
				conn.sendMessage(`${global.staff.idsal}`, {audio: {url:data.download.url}, mimetype: "audio/mpeg", ptt: true, contextInfo: {
forwardingScore: 999,
isForwarded: true, 
mentionedJid: [m.sender],
businessMessageForwardInfo: { 
businessOwnerJid: "0@s.whatsapp.net" 
},
forwardedNewsletterMessageInfo: {
newsletterName: '[🎶] ' + data.metadata.title,
newsletterJid: `${staff.idsal}`
},
externalAdReply: {
 title: data.metadata.title,
 mediaType: 1,
 previewType: 1,
 body: "Duration: " + data.metadata.timestamp,
 thumbnailUrl: data.metadata.thumbnail,
 renderLargerThumbnail: false,
 mediaUrl: Url,
 sourceUrl: Url
}}},{quoted: m});
conn.sendMessage(m.chat, { react: { text: '', key: m.key } });
			} catch (error) {
				await m.reply("error: " + error);
			}
};

handler.help = ['ach'].map(v => v + ' <query>');
handler.tags = ['main'];
handler.command = /^(ach)$/i;
handler.limit = 3
module.exports = handler