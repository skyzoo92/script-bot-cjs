const https = require("https");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const { execSync } = require("child_process");

const cooldown = new Map();

const info = global.info || { packname: "StickerBot", author: "Hydra" };
const staff = global.staff || { nameown: "Hydra" };

let handler = async (m, { conn, text, args, command, usedPrefix }) => {
    if (!global.db) global.db = { data: {} };
    if (!global.db.data.brat) global.db.data.brat = { totalUsage: 0, totalUsageVideo: 0, users: {} };
    let sender = m.sender;

    if (!global.db.data.brat.users[sender]) {
        global.db.data.brat.users[sender] = {
            nama: m.pushName || "Hah?",
            nomor: sender.split('@')[0],
            amount: 0,
            amountVideo: 0,
            attempts: 0,
            banned: false
        };
    }

    if (global.db.data.brat.users[sender]?.banned) {
        return m.reply("[❗] Anda telah dibanned dari penggunaan fitur ini.");
    }

    const quo = args.length >= 1 ? args.join(" ") : m.quoted?.text || m.quoted?.caption || m.quoted?.description || null;
    if (/^totalbrat$/i.test(command)) {
        let bratData = global.db.data.brat;
        let userStats = Object.entries(bratData.users)
            .map(([id, { nama, amount, amountVideo }]) => `@${id.split('@')[0]}: ${amount} (img), ${amountVideo} (vid)`)
            .join("\n") || "Belum ada pengguna.";
        let mentions = Object.keys(bratData.users);
        let message = `📊 *Statistik Penggunaan Brat*\n\n` +
            `*Total Penggunaan:* ${bratData.totalUsage} kali (img), ${bratData.totalUsageVideo} kali (vid)\n\n` +
            `*Pengguna:*\n${userStats}`;
        await conn.sendMessage(m.chat, { text: message, mentions }, { quoted: m });
        return;
    }

    if (/^brat(img|vid|video)$/i.test(command)) {
        if (!quo) return m.reply("[❗] Mohon input atau reply teks yang ingin dijadikan stiker.");

        if (cooldown.has(sender)) {
            const lastTime = cooldown.get(sender);
            const elapsed = (Date.now() - lastTime) / 1000;
            if (elapsed < 10) {
                const attempts = global.db.data.brat.users[sender]?.attempts || 0;
                global.db.data.brat.users[sender].attempts = attempts + 1;

                if (global.db.data.brat.users[sender].attempts >= 3) {
                    global.db.data.brat.users[sender].banned = true;
                    return m.reply("[❗] Anda telah dibanned karena spam!");
                }
                return m.reply(
                    `[❗] Tunggu ${10 - Math.floor(elapsed)} detik sebelum menggunakan perintah ini lagi.\n\nJika spam 3x, Anda akan dibanned!`
                );
            }
        }

        cooldown.set(sender, Date.now());
        global.db.data.brat.users[sender].attempts = 0;

        if (command === "bratimg") {
            global.db.data.brat.users[sender].amount += 1;
            global.db.data.brat.totalUsage += 1;
        } else {
            global.db.data.brat.users[sender].amountVideo += 1;
            global.db.data.brat.totalUsageVideo += 1;
        }

        await m.reply("Tunggu sebentar...");

        setTimeout(async () => {
            try {
                let url = "";
                if (command === "bratimg") {
                    url = `https://aqul-brat.hf.space?text=${encodeURIComponent(quo)}`;
                } else {
                    url = `https://api.fasturl.link/maker/brat/animated?text=${encodeURIComponent(quo)}&mode=animated`;
                }

                let media = await IBuffer(url);

                if (command === "bratimg") {
                    await conn.sendImageAsSticker(m.chat, media, m, {
                        packname: info.packname,
                        author: staff.nameown
                    });
                } else {
                    await conn.sendStvid(m.chat, media, m, {
                        packname: info.packname,
                        author: staff.nameown
                    });
                }

                setTimeout(() => cooldown.delete(sender), 10000);
            } catch (error) {
                console.error(error);
                m.reply("[❗] Terjadi kesalahan saat membuat stiker.");
            }
        }, 10000);
    }
};

handler.help = ["bratimg", "totalbrat", "bratvideo"];
handler.tags = ["sticker"];
handler.command = /^(bratimg|totalbrat|bratvideo|bratvid)$/i;
handler.limit = 4;
handler.group = true;

module.exports = handler;

async function IBuffer(url) {
    return new Promise((resolve, reject) => {
        https.get(url, res => {
            let data = [];
            res.on("data", chunk => data.push(chunk));
            res.on("end", () => resolve(Buffer.concat(data)));
            res.on("error", reject);
        });
    });
}