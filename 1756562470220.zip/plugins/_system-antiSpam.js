async function all(m) {
    if (!m.message) return;

    const nomorOwner = ['6287784901856@s.whatsapp.net']; // Ganti dengan nomor owner Anda, tambahkan lebih dari satu jika ada

    // Jika nomor pengirim adalah owner, abaikan proses anti-spam
    if (nomorOwner.includes(m.sender)) return;

    // Jika pesan dari bot sendiri, abaikan proses anti-spam
    if (m.fromMe) return;

    this.spam = this.spam || {};

    if (m.sender in this.spam) {
        this.spam[m.sender].count++;

        if (m.messageTimestamp.toNumber() - this.spam[m.sender].lastspam > 2) {
            if (this.spam[m.sender].count > 3) {
                global.db.data.users[m.sender].banned = true;
                m.reply(`*📮 Kamu di-banned karena spam*\n\n*💬 Laporkan masalah ini ke wa.me/${nomorOwner[0].split('@')[0]}?text=Bang+tolong+unban+nomor+ku+di+rapthalia*`);
            }
            this.spam[m.sender].count = 0;
            this.spam[m.sender].lastspam = m.messageTimestamp.toNumber();
        }
    } else {
        this.spam[m.sender] = {
            jid: m.sender,
            count: 0,
            lastspam: 0,
        };
    }
}

module.exports = { all }