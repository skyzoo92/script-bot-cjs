const hydra = require('@kelvdra/scraper');

let handler = async (m, { conn, usedPrefix, command, text }) => {
  if (!text) return m.reply(`[❗] Masukan salah!\n\nContoh: ${usedPrefix + command} The Spectre`);

  try {
    let search = await hydra.search(text);
    let videos = search.results.filter(v => v.type === "video").slice(0, 10);

    if (videos.length === 0) return m.reply(`[❗] Tidak ada hasil yang ditemukan untuk: ${text}`);

    let list = videos.map((v, i) => {
      return [`${usedPrefix}play ${v.url}`, i + 1, `${v.title} (${v.timestamp})`];
    });

    await conn.textList(m.chat, `Terdapat *${videos.length} Result*\nSilahkan pilih Audio yang kamu cari!`, false, list, m, {
      contextInfo: {
        externalAdReply: {
          title: `Hasil Pencarian`,
          body: videos[0].title,
          thumbnailUrl: videos[0].thumbnail,
          sourceUrl: videos[0].url,
          mediaType: 1,
          renderLargerThumbnail: true,
          mentionedJid: [m.sender]
        }
      }
    });
  } catch (e) {
    console.log(e);
    m.reply(`[❗] Terjadi kesalahan pada server.`);
  }
};

handler.help = ["ytsearch"].map(v => v + " <pencarian>");
handler.tags = ["downloader"];
handler.command = /^(ytsearch|yts)$/i;
handler.limit = 4;

module.exports = handler;