const fs = require('fs');
const path = require('path');

const databasePath = path.join('./database.json');

if (!fs.existsSync(databasePath)) {
    fs.writeFileSync(databasePath, '{}', 'utf-8');
}

const loadDatabase = () => JSON.parse(fs.readFileSync(databasePath, 'utf-8'));
const saveDatabase = (data) => fs.writeFileSync(databasePath, JSON.stringify(data, null, 4), 'utf-8');

let database = loadDatabase();
if (!database.antiTagSWGroup) database.antiTagSWGroup = {};
if (!database.tagCount) database.tagCount = {};

let handler = async (m, { conn, args, isAdmin, isOwner }) => {
    if (!m.isGroup) return m.reply("❌ Fitur ini hanya bisa digunakan di grup.");
    if (!(isAdmin || isOwner)) return m.reply("❌ Hanya admin yang bisa mengubah pengaturan fitur ini.");

    if (!args[0]) return m.reply("⚠️ Gunakan: .antitagsw on/off");

    if (args[0] === "on") {
        database.antiTagSWGroup[m.chat] = true;
        saveDatabase(database);
        return m.reply("✅ *Anti Tag Status WhatsApp AKTIF di grup ini!*");
    } else if (args[0] === "off") {
        database.antiTagSWGroup[m.chat] = false;
        saveDatabase(database);
        return m.reply("❌ *Anti Tag Status WhatsApp DIMATIKAN di grup ini!*");
    } else {
        return m.reply("⚠️ Pilih: on/off");
    }
};

handler.before = async (m, { conn, isBotAdmin }) => {
    if (!m.isGroup || !m.chat) return;
    
    let isAntiTagActive = database.antiTagSWGroup[m.chat] !== false; 
    
    if (!isAntiTagActive) return;
    if (!m.message?.groupStatusMentionMessage) return;

    let groupId = m.chat;
    let senderId = m.sender;
    let groupMetadata = await conn.groupMetadata(groupId);
    let botNumber = conn.user.jid;

    if (!isBotAdmin) {
        console.log("Bot bukan admin, tidak bisa kick anggota.");
        return;
    }

    database.tagCount[senderId] = (database.tagCount[senderId] || 0) + 1;
    saveDatabase(database);

    console.log(`User ${senderId} telah menge-tag ${database.tagCount[senderId]} kali.`);

    if (database.tagCount[senderId] >= 5) {
        try {
            console.log(`Mengeluarkan ${senderId} dari grup ${groupId}`);
            await conn.groupParticipantsUpdate(groupId, [senderId], 'remove');
            delete database.tagCount[senderId];
            saveDatabase(database);
        } catch (error) {
            console.error("Gagal mengeluarkan pengguna:", error);
        }
    } else {
        await conn.sendMessage(groupId, { delete: m.key });
    }
};
handler.command = handler.help = ['antitagsw'];
handler.tags = ["group"];
handler.group = true;
handler.admin = true;

module.exports = handler