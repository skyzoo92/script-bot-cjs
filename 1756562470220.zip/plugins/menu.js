const moment = require("moment-timezone");
const PhoneNumber = require("awesome-phonenumber");
const fs = require("fs");
const fetch = require("node-fetch");
const os = require("os");
const freeMemory = os.freemem();
const totalMemory = os.totalmem();
const usedMemory = totalMemory - freeMemory;
const {
  generateWAMessageFromContent,
  proto,
  prepareWAMessageMedia,
} = require("@kelvdra/bails");
const { thumb, giflogo } = global.logo
const { sgc } = global.link
const { namebot } = global.staff
const { version, wm } = global.info
const Func = new (require(process.cwd() + "/lib/func"))();

let menulist = async (m, { conn, usedPrefix, command, args }) => {
  m.react("⏱")
  const perintah = args[0] || "tags";
  const tagCount = {};
  const tagHelpMapping = {};
const user = global.db.data.users[m.sender] 


  Object.keys(global.features)
    .filter((plugin) => !plugin.disabled)
    .forEach((plugin) => {
      const tagsArray = Array.isArray(global.features[plugin].tags)
        ? global.features[plugin].tags
        : [];

      if (tagsArray.length > 0) {
        const helpArray = Array.isArray(global.features[plugin].help)
          ? global.features[plugin].help
          : [global.features[plugin].help];

        tagsArray.forEach((tag) => {
          if (tag) {
            if (tagCount[tag]) {
              tagCount[tag]++;
              tagHelpMapping[tag].push(...helpArray);
            } else {
              tagCount[tag] = 1;
              tagHelpMapping[tag] = [...helpArray];
            }
          }
        });
      }
    });

  let help = Object.values(global.features)
    .filter((plugin) => !plugin.disabled)
    .map((plugin) => {
      return {
        help: Array.isArray(plugin.tags) ? plugin.help : [plugin.help],
        tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
        prefix: "customPrefix" in plugin,
        limit: plugin.limit,
        premium: plugin.premium,
        enabled: !plugin.disabled,
      };
    });
 
 const list = Object.keys(tagCount);
let array = [];

for (let i of list) {
  array.push({
    header: `MENU ${i.toUpperCase()}`,
    title: `📝 List [ ${i} ] Features`,
    description: "",
    id: `${usedPrefix + command} ${i}`,
  });
}

let sections = [
  {
    title: "FITUR BOT",
    highlight_label: "kategori fitur",
    rows: array
  },
  {
    title: "INFORMASI BOT",
    highlight_label: "view all features",
    rows: [   
      {
        header: "✨ " + namebot,
        title: "MENU ALL",
        description: "Tampilkan semua fitur",
        id: ".menuall"
      },
      {
        header: "👤 OWNER",
        title: "Hubungi Owner",
        description: "Info Owner Bot Rapthalia",
        id: ".owner"
      },
      {
        header: "📑 About Bot",
        title: "Informasi Bot",
        description: "Info Tentang Bot Rapthalia",
        id: ".about"
      }
    ]
  }
];

  if (perintah === "tags") {
    const daftarTag = Object.keys(tagCount)
      .sort()
      .join(`\n│  ◦ ${usedPrefix + command} `);
    const more = String.fromCharCode(8206);
    const readMore = more.repeat(4001);
    let _mpt;
    if (process.send) {
      process.send("uptime");
      _mpt =
        (await new Promise((resolve) => {
          process.once("message", resolve);
          setTimeout(resolve, 1000);
        })) * 1000;
    }
    let mpt = clockString(_mpt);
    let name = `@${m.sender.split`@`[0]}`;
    let prn = thumb;
    let fitur = Object.values(features)
      .filter((v) => v.help && !v.disabled)
      .map((v) => v.help)
      .flat(1);
    let rapthalia = `${
      global.menu === "button"
        ? `🌟 Hi ${name}
${namebot} Adalah sistem otomatis whatsApp yang dapat membantu anda dalam hal apapun di WhatsApp!!

saya di desain oleh Seorang Developer hebat yang mengembangkan bot whatsApp berbasis Javascript ini dengan menyajikan beberapa fitur seperti *AI*, *DOWNLOADER*, *GAME*, dan lainnya 

┌  ◦ *Name Bot :* ${namebot}
│  ◦ *Total User :* ${Func.formatNumber(Object.keys(db.data.users).length)}
│  ◦ *Total Chat:* ${Object.keys(conn.chats).length}
│  ◦ *Uptime :* ${Func.toDate(process.uptime() * 1000)} *[${Func.toTime(process.uptime() * 1000)}]*
│  ◦ *Total Memory :* ${Func.formatSize(totalMemory)}
│  ◦ *Free Memory :* ${Func.formatSize(freeMemory)}
└  ◦ *Used Memory :* ${Func.formatSize(usedMemory)}

┌  ◦ *Name User :* ${m.name}
│  ◦ *Tag User :* ${name}
│  ◦ *Limit User  :* ${user.limit}
│  ◦ *Premium :* ${user.premium ? "✓" : "x"}
└  ◦ *Saldo User :* ${Func.formatNumber(user.saldo)} Rp

*® PRESS BUTTON BELOW TO VIEW LIST OF FEATURES*`
        : `🌟 Hi ${name}
${namebot} Adalah sistem otomatis whatsApp yang dapat membantu anda dalam hal apapun di WhatsApp!!

saya di desain oleh Seorang Developer hebat yang mengembangkan bot whatsApp berbasis Javascript ini dengan menyajikan beberapa fitur seperti *AI*, *DOWNLOADER*, *GAME*, dan lainnya 

┌  ◦ *Name Bot :* ${namebot}
│  ◦ *Total User :* ${Func.formatNumber(Object.keys(db.data.users).length)}
│  ◦ *Total Chat:* ${Object.keys(conn.chats).length}
│  ◦ *Uptime :* ${Func.toDate(process.uptime() * 1000)} *[${Func.toTime(process.uptime() * 1000)}]*
│  ◦ *Total Memory :* ${Func.formatSize(totalMemory)}
│  ◦ *Free Memory :* ${Func.formatSize(freeMemory)}
└  ◦ *Used Memory :* ${Func.formatSize(usedMemory)}

┌  ◦ *Name User :* ${m.name}
│  ◦ *Tag User :* ${name}
│  ◦ *Limit User  :* ${user.limit}
│  ◦ *Premium :* ${user.premium ? "✓" : "x"}
└  ◦ *Saldo User :* ${Func.formatNumber(user.saldo) || "0"} Rp
${readMore}

┌  ◦ ${usedPrefix + command} all
│  ◦ ${usedPrefix + command} ${daftarTag}
└————`
    }

`;

    if (global.menu === "simple") {
      conn.reply(m.chat, rapthalia, fkontak);
    } else if (global.menu === "doc") {
      conn.sendMessage(
        m.chat,
        {
          document: {
            url: "https://wa.me/" + conn.user.jid.split("@")[0],
          },
          jpegThumbnail: await conn.resize(thumb, 300, 150),
          caption: rapthalia,
          mimetype: "text/html",
          fileName: `© Rapthalia-Bot [ ver ${version} ]\n• Uptime: ${Func.toDate(process.uptime() * 1000)}`,
          contextInfo: {
            mentionedJid: conn.parseMention(rapthalia),
            isForwarded: true,
            businessMessageForwardInfo: {
              businessOwnerJid: conn.user.jid,
            },
          },
        },
        { quoted: fkontak },
      );
    } else if (global.menu === "gif") {
      conn.sendMessage(
        m.chat,
        {
          video: { url: giflogo },
          gifPlayback: true,
          gifAttribution: ~~(Math.random() * 2),
          caption: rapthalia,
          contextInfo: {
            mentionedJid: conn.parseMention(rapthalia),
            externalAdReply: {
              title: `© Rapthalia-Bot [ ver ${version} ]\n• Uptime: ${Func.toDate(process.uptime() * 1000)}`,
              body: wm,
              thumbnailUrl: thumb,
              sourceUrl: sgc,
              mediaType: 1,
              renderLargerThumbnail: true,
            },
          },
        },
        { quoted: fkontak },
      );
    } else if (global.menu === "payment") {
      await conn.relayMessage(
        m.chat,
        {
          requestPaymentMessage: {
            currencyCodeIso4217: "USD",
            amount1000:
              Object.values(features)
                .filter((v) => v.help && !v.disabled)
                .map((v) => v.help)
                .flat(1).length * 1000,
            requestFrom: m.sender,
            noteMessage: {
              extendedTextMessage: {
                text: rapthalia,
                contextInfo: {
                  mentionedJid: conn.parseMention(rapthalia),
                  externalAdReply: {
                    showAdAttribution: true,
                  },
                },
              },
            },
          },
        },
        {},
      );
    } else if (global.menu === "edit") {
      const arr = [
        "➳ *L*",
        "➳ *L O*",
        "➳ *L O A*",
        "➳ *L O A D*",
        "➳ *L O A D I*",
        "➳ *L O A D I N*",
        "➳ *L O A D I N G*",
        "➳ *L O A D I N G .*",
        "➳ *L O A D I N G . .*",
        "➳ *L O A D I N G . . .*",
        "➳ *L O A D I N G . .*",
        "➳ *L O A D I N G .*",
        "➳ *L O A D I N G*",
        "➳ *W E L C O M E  T O  R A P T H A L I A*",
        rapthalia,
      ];

      let { key } = await conn.sendMessage(
        m.chat,
        {
          document: {
            url: "https://wa.me/" + conn.user.jid,
          },
          jpegThumbnail: await conn.resize(thumb, 300, 150),
          caption: `➳ *Please Waif...*`,
          mimetype: "text/html",
          fileName: `© Rapthalia-Bot [ ver ${version} ]\n• Uptime: ${Func.toDate(process.uptime() * 1000)}`,
          contextInfo: {
            mentionedJid: conn.parseMention(rapthalia),
            isForwarded: true,
            businessMessageForwardInfo: {
              businessOwnerJid: conn.user.jid,
            },
          },
        },
        { quoted: fkontak },
      );
      for (let i = 0; i < arr.length; i++) {
        await conn.sendMessage(
          m.chat,
          {
            document: {
              url: "https://wa.me",
            },
            jpegThumbnail: await conn.resize(thumb, 300, 150),
            caption: arr[i],
            mimetype: "text/html",
            fileName: `© Rapthalia-Bot [ ver ${version} ]\n• Uptime: ${Func.toDate(process.uptime() * 1000)}`,
            edit: key,
            contextInfo: {
              mentionedJid: conn.parseMention(rapthalia),
              isForwarded: true,
              businessMessageForwardInfo: {
                businessOwnerJid: conn.user.jid,
              },
            },
          },
          { quoted: fkontak },
        );
      }
    } else if (global.menu === "button") {
await conn.sendList(m.chat, "Click The Open", sections, m, {
  body: rapthalia,
  footer: "Powered by Hydra",
  url: thumb
});
let delay = time => new Promise(res => setTimeout(res, time));
await delay(10000);
conn.sendMessage(m.chat, {
    audio: { url: "https://files.catbox.moe/x8slfm.mp3" },
    mimetype: "audio/mpeg",
    ptt: true,
    contextInfo: {
        isForwarded: true,
        mentionedJid: [m.sender],
        businessMessageForwardInfo: {
            businessOwnerJid: "0@s.whatsapp.net"
        },
        forwardedNewsletterMessageInfo: {
            newsletterName: `Powered By Hydra`,
            newsletterJid: staff.idsal
        }
    }
}, { quoted: m });
    }
  } else if (tagCount[perintah]) {
    const daftarHelp = tagHelpMapping[perintah]
      .map((helpItem, index) => {
        return `${helpItem}`;
      })
      .join("\n│  ◦ " + " ");
    let rapthalia = `┌  ◦ *📝 MENU ${perintah.toUpperCase()}*
│  ◦ ${usedPrefix + daftarHelp}
└———
`;

    if (global.menu === "simple") {
      conn.reply(m.chat, rapthalia, fkontak);
    } else if (global.menu === "doc") {
      conn.sendMessage(
        m.chat,
        {
          document: {
            url: "https://wa.me/" + conn.user.jid,
          },
          jpegThumbnail: await conn.resize(thumb, 300, 150),
          caption: rapthalia,
          mimetype: "text/html",
          fileName: `© Rapthalia-Bot [ ver ${version} ]\n• Uptime: ${Func.toDate(process.uptime() * 1000)}`,
          contextInfo: {
            mentionedJid: conn.parseMention(list),
            isForwarded: true,
            businessMessageForwardInfo: {
              businessOwnerJid: conn.user.jid,
            },
          },
        },
        { quoted: fkontak },
      );
    } else if (global.menu === "gif") {
      conn.sendMessage(
        m.chat,
        {
          video: { url: giflogo },
          gifPlayback: true,
          gifAttribution: ~~(Math.random() * 2),
          caption: rapthalia,
          contextInfo: {
            mentionedJid: conn.parseMention(rapthalia),
            externalAdReply: {
              title: `© Rapthalia-Bot [ ver ${version} ]\n• Uptime: ${Func.toDate(process.uptime() * 1000)}`,
              body: wm,
              thumbnailUrl: thumb,
              sourceUrl: sgc,
              mediaType: 1,
              renderLargerThumbnail: true,
            },
          },
        },
        { quoted: fkontak },
      );
    } else if (global.menu === "payment") {
      await conn.relayMessage(
        m.chat,
        {
          requestPaymentMessage: {
            currencyCodeIso4217: "USD",
            amount1000:
              Object.values(features)
                .filter((v) => v.help && !v.disabled)
                .map((v) => v.help)
                .flat(1).length * 1000,
            requestFrom: m.sender,
            noteMessage: {
              extendedTextMessage: {
                text: rapthalia,
                contextInfo: {
                  mentionedJid: conn.parseMention(rapthalia),
                  externalAdReply: {
                    showAdAttribution: true,
                  },
                },
              },
            },
          },
        },
        {},
      );
    } else if (global.menu === "edit") {
      const arr = [
        "➳ *L*",
        "➳ *L O*",
        "➳ *L O A*",
        "➳ *L O A D*",
        "➳ *L O A D I*",
        "➳ *L O A D I N*",
        "➳ *L O A D I N G*",
        "➳ *L O A D I N G .*",
        "➳ *L O A D I N G . .*",
        "➳ *L O A D I N G . . .*",
        "➳ *L O A D I N G . .*",
        "➳ *L O A D I N G .*",
        "➳ *L O A D I N G*",
        "➳ *W E L C O M E  T O  R A P T H A L I A*",
        rapthalia,
      ];

      let { key } = await conn.sendMessage(
        m.chat,
        {
          document: {
            url: "https://wa.me/" + conn.user.jid,
          },
          jpegThumbnail: await conn.resize(thumb, 300, 150),
          caption: `➳ *Please Waif...*`,
          mimetype: "text/html",
          fileName: `© Rapthalia-Bot [ ver ${version} ]\n• Uptime: ${Func.toDate(process.uptime() * 1000)}`,
          contextInfo: {
            mentionedJid: conn.parseMention(rapthalia),
            isForwarded: true,
            businessMessageForwardInfo: {
              businessOwnerJid: conn.user.jid,
            },
          },
        },
        { quoted: fkontak },
      );
      for (let i = 0; i < arr.length; i++) {
        await conn.sendMessage(
          m.chat,
          {
            document: {
              url: "https://wa.me",
            },
            jpegThumbnail: await conn.resize(thumb, 300, 150),
            caption: arr[i],
            mimetype: "text/html",
            fileName: `© Rapthalia-Bot [ ver ${version} ]\n• Uptime: ${Func.toDate(process.uptime() * 1000)}`,
            edit: key,
            contextInfo: {
              mentionedJid: conn.parseMention(rapthalia),
              isForwarded: true,
              businessMessageForwardInfo: {
                businessOwnerJid: conn.user.jid,
              },
            },
          },
          { quoted: fkontak },
        );
      }
    } else if (menu === "button") {
      await conn.sendList(m.chat, "Click The Open", sections, m, {
  body: rapthalia,
  footer: "Powered by Hydra",
  url: thumb
});
    }
  } else {
    await conn.reply(
      m.chat,
      `*[ MENU ${perintah.toUpperCase()} NOT FOUND ]*\n> • _Ketik *.menu* untuk melihat semua kategori menu atau keitk *.menu all* untuk melihat semua fitur_`,
      m,
    );
    m.react("❌")
  }
  m.react("")
};

menulist.help = ["menu"].map((a) => a + " *[view main menu]*");
menulist.tags = ["main"];
menulist.command = ["menu"];

module.exports = menulist;

function clockString(ms) {
  let h = isNaN(ms) ? "--" : Math.floor(ms / 3600000);
  let m = isNaN(ms) ? "--" : Math.floor(ms / 60000) % 60;
  let s = isNaN(ms) ? "--" : Math.floor(ms / 1000) % 60;
  return [h, m, s].map((v) => v.toString().padStart(2, 0)).join(":");
}