let handler = async (m, { text, conn, command }) => {
  let user = global.db.data.users[m.sender]

  // Jika user sedang AFK dan kirim pesan, dianggap sudah kembali
  if (typeof user.afk === 'number' && user.afk > -1) {
    m.reply(`
Kamu berhenti AFK${user.afkReason ? ' setelah ' + user.afkReason : ''}
Selama ${clockString(new Date - user.afk)}
`.trim())
    user.afk = -1
    user.afkReason = ''
  }

  // Peringatan kalau mention user yang sedang AFK
  let jids = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
  for (let jid of jids) {
    let mentionedUser = global.db.data.users[jid]
    if (!mentionedUser) continue
    let afkTime = mentionedUser.afk
    if (!afkTime || afkTime < 0) continue
    let reason = mentionedUser.afkReason || ''
    m.reply(`
Jangan tag dia!
Dia sedang AFK ${reason ? 'dengan alasan ' + reason : 'tanpa alasan'}
Selama ${clockString(new Date - afkTime)}
`.trim())
  }

  // Set AFK
  if (command === 'afk') {
    user.afk = +new Date
    user.afkReason = text
    m.reply(`${conn.getName(m.sender)} sekarang AFK${text ? ': ' + text : ''}`)
  }

  // List AFK
  if (command === 'listafk') {
    let users = Object.entries(global.db.data.users)
      .filter(([_, data]) => data.afk && data.afk > -1)

    if (users.length === 0) return m.reply('Tidak ada yang sedang AFK.')

    let list = users.map(([jid, data], i) => {
      let name = conn.getName ? conn.getName(jid) : jid.split('@')[0]
      let reason = data.afkReason ? ` (${data.afkReason})` : ''
      let time = clockString(new Date - data.afk)
      return `${i + 1}. ${name}${reason}\n   Selama: ${time}`
    }).join('\n\n')

    m.reply(`*List Pengguna AFK:*\n\n${list}`)
  }
}

handler.help = ['afk [alasan]', 'listafk']
handler.tags = ['main']
handler.command = /^afk$|^listafk$/i
handler.limit = true
handler.before = true

module.exports = handler

function clockString(ms) {
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}