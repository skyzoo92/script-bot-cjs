/**
 * By: Hydra
 * 𝘵𝘦𝘭𝘦: https://t.me/draa82
 * 𝘪𝘯𝘧𝘰: https://s.id/Genzo82
 * 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VadrgqYKbYMHyMERXt0e
 * 🚨Di Larang Menghapus Wm Ini🚨
 * #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁
**/

const { createHash } = require('crypto')
const Reg = /\|?(.*)([.|] *?)([0-9]*)$/i

let handler = async function (m, { args, usedPrefix, command }) {
  let user = global.db.data.users[m.sender]
  let sn = createHash('md5').update(m.sender).digest('hex')
  user.registered = false
  user.unreg = true
  m.reply(`📛Kamu Berhasil keluar dari database dengan code sn ${sn}\n\nRapthalia - AI`)
}
handler.help = ['unreg']
handler.tags = ['main']
handler.command = ["unreg"]
handler.register = true

module.exports = handler