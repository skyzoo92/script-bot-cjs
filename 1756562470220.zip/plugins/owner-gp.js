const fs = require('fs')
const path = require('path')

let handler = async (m, { conn, usedPrefix, command, text }) => {
    const PLUGIN_DIR = path.resolve(process.cwd(), 'plugins')
    if (!text) throw `Format salah!\n\nGunakan:\n${usedPrefix + command} <nama_file>\n\nContoh:\n${usedPrefix + command} menu.js`
    
    // Auto tambahkan ekstensi .js kalau belum ada
    if (!text.endsWith('.js')) text += '.js'
    
    let filePath = path.resolve(PLUGIN_DIR, text)
    
    if (!filePath.startsWith(PLUGIN_DIR)) throw '⚠️ Akses ke luar folder plugins tidak diperbolehkan!'
    
    if (!fs.existsSync(filePath)) {
        let fileList = fs.readdirSync(PLUGIN_DIR)
            .filter(file => fs.statSync(path.join(PLUGIN_DIR, file)).isFile())
            .map(file => `- ${file}`)
            .join('\n')
        throw `❌ File tidak ditemukan di folder plugins!\n\nBerikut daftar file yang tersedia:\n${fileList}`
    }
    
    await conn.sendMessage(m.chat, { 
        document: { url: filePath }, 
        fileName: path.basename(filePath), 
        mimetype: 'application/octet-stream' 
    }, { quoted: m })
}

handler.help = ['getplugins <nama_file>']
handler.tags = ['owner']
handler.command = /^getplugins|gp$/i
handler.rowner = true

module.exports = handler