let handler = async (m, { conn, args, text, command, usedPrefix }) => {
  const chat = m.chat
  global.players = global.players || {}
  global.words = global.words || {}
  global.spyWord = global.spyWord || {}
  global.spy = global.spy || {}
  global.gameStarted = global.gameStarted || {}
  global.votes = global.votes || {}
  global.currentPlayerIndex = global.currentPlayerIndex || {}
  global.roundTimer = global.roundTimer || {}
  global.votingTimer = global.votingTimer || {}
  global.descriptions = global.descriptions || {}

  players[chat] = players[chat] || []
  words[chat] = words[chat] || []
  spyWord[chat] = spyWord[chat] || null
  spy[chat] = spy[chat] || null
  gameStarted[chat] = gameStarted[chat] || false
  votes[chat] = votes[chat] || {}
  currentPlayerIndex[chat] = currentPlayerIndex[chat] || 0
  roundTimer[chat] = roundTimer[chat] || null
  votingTimer[chat] = votingTimer[chat] || null
  descriptions[chat] = descriptions[chat] || []

  const data = await fetch("https://www.vreden.my.id/cdn/game/spyWord.json")

  function resetGame() {
    players[chat] = []
    spy[chat] = null
    gameStarted[chat] = false
    votes[chat] = {}
    currentPlayerIndex[chat] = 0
    descriptions[chat] = []
    clearTimeout(roundTimer[chat])
    clearTimeout(votingTimer[chat])
  }

  function assignWords() {
    const selectedPair = data.words[Math.floor(Math.random() * data.words.length)]
    words[chat] = players[chat].map((p, i) => (i === spy[chat] ? selectedPair.spyWord : selectedPair.worldWord))
  }

  async function startGame() {
    if (players[chat].length === 4) {
      gameStarted[chat] = true
      spy[chat] = Math.floor(Math.random() * players[chat].length)
      assignWords()

      for (let i = 0; i < players[chat].length; i++) {
        await conn.sendText(players[chat][i], `Kata kamu adalah "${words[chat][i]}". Cari tahu siapa Spy di antara kalian.`)
      }

      m.reply('Permainan dimulai! Setiap pemain akan menyebutkan ciri-ciri kata mereka satu per satu.')
      await sleep(3000)
      currentPlayerIndex[chat] = 0
      await startTurn()
    } else {
      m.reply(`Harus ada 4 pemain untuk memulai permainan! Saat ini ada ${players[chat].length} pemain.`)
    }
  }

  async function startTurn() {
    if (currentPlayerIndex[chat] >= players[chat].length) {
      let desc = "List Deskripsi:\n"
      for (let i = 0; i < players[chat].length; i++) {
        desc += `@${players[chat][i].split("@")[0]}: ${descriptions[chat][i] || "Belum memberikan deskripsi"}\n`
      }

      await conn.sendMessage(chat, { text: desc, mentions: players[chat] })
      await sleep(3000)
      conn.sendText(chat, `Semua pemain sudah menyebutkan ciri-ciri kata mereka. Sekarang saatnya vote!\n\nGunakan *${usedPrefix + command} vote @tag* untuk vote siapa Spy.`)
      startVoting()
      return
    }

    const current = players[chat][currentPlayerIndex[chat]]
    if (!descriptions[chat][currentPlayerIndex[chat]]) {
      conn.sendMessage(chat, {
        text: `Giliran @${current.split("@")[0]}!\nKamu punya 30 detik untuk menyebutkan ciri-ciri kata kamu.\n\nKetik *${usedPrefix + command} describe*`,
        mentions: [current]
      })
    } else {
      currentPlayerIndex[chat]++
      await startTurn()
    }

    roundTimer[chat] = setTimeout(() => {
      currentPlayerIndex[chat]++
      startTurn()
    }, 30000)
  }

  function addDescription(player, desc) {
    const idx = players[chat].indexOf(player)
    if (idx !== -1) descriptions[chat][idx] = desc
  }

  function startVoting() {
    votes[chat] = {}

    votingTimer[chat] = setTimeout(() => {
      if (Object.keys(votes[chat]).length === 0) {
        m.reply('Tidak ada vote yang dilakukan. Permainan akan direset.')
        return resetGame()
      }

      let voteCounts = {}, max = 0, outPlayer = null
      for (let voter in votes[chat]) {
        const vote = votes[chat][voter]
        voteCounts[vote] = (voteCounts[vote] || 0) + 1
        if (voteCounts[vote] > max) {
          max = voteCounts[vote]
          outPlayer = vote
        }
      }

      if (Object.values(voteCounts).filter(v => v === max).length > 1) {
        m.reply('Voting seri! Mari kita lakukan voting ulang.')
        return startVoting()
      }

      if (outPlayer === players[chat][spy[chat]]) {
        conn.sendMessage(chat, {
          text: `@${outPlayer.split("@")[0]} adalah Spy!\n\n*Kalian menang🏆*\n• + Rp 1000 saldo\n\n*Denda spy😹*\n• - Rp 1000 saldo`,
          mentions: [outPlayer]
        })
        players[chat].forEach(p => {
          if (p !== outPlayer) global.db.data.users[p].saldo += 1000
          else global.db.data.users[p].saldo -= 1000
        })
      } else {
        conn.sendMessage(chat, {
          text: `@${outPlayer.split("@")[0]} bukan Spy!\n\n*Spy menang🏆*\n• + Rp 1000 saldo\n\n*Denda warga😹*\n• - Rp 1000 saldo`,
          mentions: [outPlayer]
        })
        players[chat].forEach(p => {
          if (p !== outPlayer) global.db.data.users[p].saldo -= 1000
          else global.db.data.users[p].saldo += 1000
        })
      }
      resetGame()
    }, 120000)
  }

  switch (args[0]) {
    case 'join':
      if (players[chat].length < 4 && !players[chat].includes(m.sender)) {
        players[chat].push(m.sender)
        conn.sendMessage(chat, {
          text: `Player @${m.sender.split("@")[0]} telah bergabung! (${players[chat].length}/4)`,
          mentions: [m.sender]
        })

        await sleep(3000)
        if (players[chat].length === 4 && !gameStarted[chat]) {
          await startGame()
        }
      } else if (players[chat].includes(m.sender)) {
        m.reply('Kamu sudah terdaftar sebagai pemain.')
      } else {
        m.reply('Permainan sudah penuh. Tunggu permainan berikutnya.')
      }
      break

    case 'describe':
      if (!gameStarted[chat]) return m.reply('Permainan belum dimulai.')
      if (!players[chat].includes(m.sender)) return m.reply('Kamu bukan bagian dari permainan ini.')
      if (!args[1]) return m.reply('Tolong masukkan deskripsi kata.')
      addDescription(m.sender, args.slice(1).join(' '))
      m.reply('Deskripsi kamu telah disimpan.')
      break

    case 'vote':
      let voted = m.mentionedJid[0] || (m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
      if (!gameStarted[chat]) return m.reply('Belum ada permainan yang dimulai.')
      if (!votingTimer[chat]) return m.reply('Vote game belum dimulai.')
      if (!players[chat].includes(m.sender)) return m.reply('Kamu bukan bagian dari permainan ini.')
      if (!voted) return m.reply("Masukkan user yang mau di-vote.")

      const index = players[chat].findIndex(p => p === voted)
      if (index === -1) return m.reply('Pemain yang kamu vote tidak ada.')

      votes[chat][m.sender] = voted
      conn.sendMessage(chat, {
        text: `@${m.sender.split("@")[0]} telah memilih @${voted.split("@")[0]}.`,
        mentions: [m.sender, voted]
      })

      if (Object.keys(votes[chat]).length === players[chat].length) {
        clearTimeout(votingTimer[chat])
      }
      break

    case 'reset':
      resetGame()
      m.reply('Permainan telah direset. Gunakan /join untuk memulai permainan baru.')
      break

    default:
      let teks = `*🕵🏻‍♂️ WHO'S THE SPY 🕵🏻‍♀️*

Permainan "Who's the Spy?" adalah permainan berbasis kata-kata di mana sekelompok pemain mencoba menebak siapa di antara mereka yang menjadi "mata-mata" atau "spy".

*Command*:
${usedPrefix + command} join
${usedPrefix + command} describe
${usedPrefix + command} vote
${usedPrefix + command} reset
`
      conn.sendMessage(chat, {
        text: teks,
        contextInfo: {
          mentionedJid: players[chat],
          externalAdReply: {
            title: `WePlay Games 🎮`,
            previewType: "PHOTO",
            thumbnailUrl: `https://pomf2.lain.la/f/rmz4e52e.jpg`,
            sourceUrl: link.sgc,
          }
        }
      }, { quoted: m })
  }
}

handler.help = ['spy']
handler.tags = ['game']
handler.command = /^spy$/i
handler.group = true
module.exports = handler

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms))
}