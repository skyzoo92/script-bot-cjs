const handler = async (m, { text }) => {
  if (!text) {
    return m.reply("Masukan query");
  }

  m.react("💬");

  try {
    const ask = m.quoted && m.quoted.text
      ? `AI : "${m.quoted.text}"\n\nUser : ${text}`
      : `User : ${text}`;

    const response = await hydra.askAI(text, "gpt-4.1");
    const result = response.results

    if (!result) {
      throw new Error("Tidak ada jawaban dari API.");
    }
    conn.sendMessage(m.chat, {
     text: `${result}`,
      contextInfo: {
                externalAdReply: {
                 title: `OPENAI AI`,
                 thumbnailUrl: 'https://files.catbox.moe/z8gov7.jpg',
                 sourceUrl: 'https://chatgpt.com/',
                 mediaType: 1,
                 renderLargerThumbnail: false,
                 mentionedJid: [m.sender]
                 }}}, { quoted: m })
       m.react("")
  } catch (error) {
    console.error("Terjadi kesalahan:", error);
    m.reply("Terjadi kesalahan saat mengakses API.");
    m.react("❌")
  }
};

handler.help = ["ai", "chatgpt"];
handler.tags = ["ai"];
handler.command = /^(openai|ai|chatgpt)$/i;
handler.limit = 4
module.exports = handler