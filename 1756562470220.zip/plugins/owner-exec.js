let cp = require('child_process')
let { promisify } = require('util')
let util = require('util')
let exec = promisify(cp.exec).bind(cp)

let handler = async (m, { conn, command, text }) => {
  if (global.conn.user.jid != conn.user.jid) return
  
  // Kirim pesan awal
  let { key } = await conn.sendMessage(m.chat, { text: "Executing..." }, { quoted: m })

  try {
    let o = await exec(command.trimStart() + ' ' + text.trimEnd())
    let { stdout, stderr } = o
    let output = stdout.trim() || stderr.trim() || "✅ Perintah berhasil tanpa output."
    
    // Edit pesan dengan hasil
    await conn.sendMessage(m.chat, {
      text: util.format(output),
      edit: key
    })
  } catch (err) {
    // Kalau error eksekusi, edit pesan dengan error
    await conn.sendMessage(m.chat, {
      text: util.format(err),
      edit: key
    })
  }
}

handler.help = ["$"]
handler.tags = ["owner"]
handler.customPrefix = /^[$] /
handler.command = new RegExp
handler.owner = true

module.exports = handler