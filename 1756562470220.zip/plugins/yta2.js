const hydra = require("@kelvdra/scraper");

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return m.reply("Mana linknya?");

  try {
    const data = await hydra.ytmp4(text); // Tambahkan 'await'

    if (!data || !data.download || !data.download.url) {
      return m.reply("Gagal mengambil video. Pastikan link YouTube valid.");
    }

    await conn.sendMessage(m.chat, {
      audio: { url: data.download.url },
      caption: `🎬 Quality: ${data.download.quality}`,
    }, { quoted: m });

  } catch (err) {
    console.error(err);
    m.reply("Terjadi kesalahan saat memproses permintaan.");
  }
};

handler.command = ["yta2"];
module.exports = handler;