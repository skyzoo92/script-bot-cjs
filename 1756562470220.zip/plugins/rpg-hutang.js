let handler = async (m, { conn, command }) => {
  let user = global.db.data.users[m.sender]
  const caption = `
       *H U T A N G  U S E R*
📛 *Name:* ${user.registered ? user.name : conn.getName(m.sender)}
💹 *Money:* ${user.money} 💲
`.trim()
  
  await m.reply(caption)
}
handler.help = ['hutang']
handler.tags = ['rpg']
handler.command = /^(hutang)$/i

handler.register = false
module.exports = handler