let handler = async (m, { conn, text }) => {
  if (!text) return m.reply('Teks tidak boleh kosong!');

  try {
    conn.sendMessage(`${staff.idsal}`, {
            text: `${text}`,
            contextInfo: {
                externalAdReply: {
                    title: name,
                    body: 'Pesan dari: ' + name,
                    thumbnailUrl: pp,
                    sourceUrl: '',
                    mediaType: 1,
                    renderLargerThumbnail: false, 
                }
            }
        }, { quoted: m });

        m.reply(`D o n e ✔️\n> Pesan berhasil dikirim ke \`\`\`${link.saluran}\`\`\``);
  } catch (err) {
    console.error(err);
    m.reply('❌ Gagal mengirim pesan: ' + err.message);
  }
};

handler.help = ['text2ch <text>'];
handler.command = /^(aplud|text2ch|tch)$/i;
handler.tags = ['main'];

module.exports = handler;