let handler = async (m, { conn, text, command }) => {
  const menuTypes = ['doc', 'simple', 'gif', 'payment', 'edit', 'button'];

  if (text && menuTypes.includes(text)) {
    global.menu = text;
    return m.reply(`✅ Sukses set menu menjadi *${text}*`);
  }

  const sections = [
    {
      title: "PILIH TIPE TAMPILAN MENU",
      rows: menuTypes.map(type => ({
        title: `Set menu ke ${type}`,
        description: `Ubah tampilan menu menjadi ${type}`,
        id: `.${command} ${type}`
      }))
    }
  ];

  const listMessage = {
    title: "SET MENU BOT",
    body: "Silakan pilih salah satu tampilan menu di bawah ini:",
    footer: "Hydra - Bot Setting Panel",
    buttonText: "Klik untuk memilih",
    sections
  };

  await conn.sendList(m.chat, listMessage.title, listMessage.sections, m, {
    body: listMessage.body,
    footer: listMessage.footer,
    buttonText: listMessage.buttonText
  });
};

handler.help = ['setmenu'];
handler.tags = ['owner'];
handler.command = /^setmenu$/i;
handler.rowner = true;

module.exports = handler;