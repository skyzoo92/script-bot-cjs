/**
 * By: Hydra
 * 𝘵𝘦𝘭𝘦: https://t.me/draa82
 * 𝘪𝘯𝘧𝘰: https://s.id/Genzo82
 * 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VadrgqYKbYMHyMERXt0e
 * 🚨Di Larang Menghapus Wm Ini🚨
 * #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁
**/

let handler = async (m, { conn, usedPrefix: _p, __dirname, args, command}) => {
m.react("⏱")
 const text = `\`WhatsApp Bot Multi Device\`\n`
    const caption = `\n👋🏻 Hai kak @${m.sender.split("@")[0]}, \nIni Owner RAPTHALIA Tercinta\nJangan Di Spam Yah Ka\n`;

await conn.sendMessage(m.chat, {
  carouselMessage: {
    caption: caption,
    footer: info.wm,
    cards: [
      {
        headerTitle: 'Hydra',
        headerSubtitle: 'Owner',
        imageUrl: "https://files.catbox.moe/0vir6m.jpg",
        productTitle: '👑 Owner Bot Rapthalia',
        productDescription: 'Hubungi Owner langsung',
        url: 'https://t.me/ownerhydra',
        bodyText: '[𝐇𝐲𝐝𝐫𝐚]\n- *Chat Yang Penting Aja*\n- *Jangan Telpon/Call Owner*\n- *Chat Langsung Ke Inti*\n- *Ada Yang Error?, Laporan Kesini*\n',
        buttons: [
          {
            name: 'cta_call',
            params: {
              display_text: 'Call Owner',
              phone_number: '+6281918402014'
            }
          },
          {
            name: 'cta_url',
            params: {
              display_text: 'Chat Telegram',
              url: 'https://t.me/ownerhydra',
              merchant_url: 'https://t.me/ownerhydra'
            }
          }
        ]
      },
      {
        headerTitle: 'Rapthalia',
        headerSubtitle: 'Bot',
        imageUrl: "https://files.catbox.moe/68wa8k.jpg",
        productTitle: '🤖 Bot Rapthalia',
        productDescription: 'Bot yang bisa kamu sewa',
        url: 'https://wa.me/6281918402014',
        bodyText: '[𝐑𝐚𝐩𝐭𝐡𝐚𝐥𝐢𝐚 𝐀𝐢]\n-  *Jangan Spam Bot*\n- *Jangan Telpon/Call Bot*\n- *Jangan Chat Aneh Aneh*\n- *Sewa Bot DLL Chat Owner*\n',
        buttons: [
          {
            name: 'cta_call',
            params: {
              display_text: 'Call Bot',
              phone_number: '+6281234567890'
            }
          },
          {
            name: 'cta_url',
            params: {
              display_text: 'Chat Bot',
              url: `https://wa.me/${staff.nomorbot}`,
              merchant_url: `https://wa.me/${staff.nomorbot}`
            }
          }
        ]
      }
    ]
  }
}, { quoted: m })
m.react("")
}
handler.help = ["owner"]
handler.tags = ["info"]
handler.command = ["owner","creator"]

module.exports = handler