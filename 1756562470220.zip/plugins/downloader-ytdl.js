/**
 * By: Hydra
 * 𝘵𝘦𝘭𝘦: https://t.me/draa82
 * 𝘪𝘯𝘧𝘰: https://s.id/Genzo82
 * 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VadrgqYKbYMHyMERXt0e
 * 🚨Dilarang Menghapus WM Ini🚨
 */

const hydra = require("@kelvdra/scraper")

let handler = async (m, { conn, text, usedPrefix, command }) => {
  let [url, q] = text.split(' ');
  if (!url) return m.reply(`Format: ${usedPrefix + command} <url> [resolusi]`);

  try {
    m.react("⏱")
if (/yta|ytmp3|ytaudio/i.test(command)) {
  let data = await hydra.ytmp3(url, q || 'mp3');
  
   conn.sendMessage(m.chat, {
    audio: { url: data.download.url },
    mimetype: 'audio/mpeg',
    fileName: `${data.metadata.title || 'yt_audio'}.mp3`,
    contextInfo: {
      externalAdReply: {
        title: `乂 YTMP3 - ${data.download.quality || '128kbps'}`,
        body: data.metadata.title || 'YouTube Audio',
        mediaType: 1,
        previewType: 0,
        renderLargerThumbnail: true,
        thumbnailUrl: data.metadata.thumbnail || '',
        sourceUrl: url,
      }
    }
  }, { quoted: m });
    } else {
      let data = await hydra.ytmp4(url, q || '360');
      let cap = `*${data.metadata.title}*\n\n⌬ Ext: Download\n⌬ ID: ${data.metadata.videoId}\n⌬ Durasi: ${data.metadata.timestamp}\n⌬ Upload: ${data.metadata.ago}\n⌬ Views: ${data.metadata.views}\n⌬ Quality: ${data.download.quality}\n⌬ Channel: ${data.metadata.author.name}`;
      await conn.sendFile(m.chat, data.download.url, `${data.metadata.title}.mp4`, cap, m);
    }
    m.react("")
  } catch (e) {
    m.reply('❌ Gagal:\n' + e);
  }
};

handler.help = ['yta <url> [resolusi]', 'ytv <url> [resolusi]'];
handler.tags = ['downloader'];
handler.command = /^(ytaudio|ytmp3|yta|ytvideo|ytmp4|ytv)$/i;
handler.limit = 3;
handler.register = true;

module.exports = handler