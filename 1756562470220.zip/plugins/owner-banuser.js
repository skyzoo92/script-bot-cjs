let handler = async (m, { conn, isOwner, text }) => {
  if (!isOwner) {
    global.dfail('owner', m, conn)
    throw false
  }

  if (!text) throw 'Masukkan nomor atau tag user yang ingin di-ban\n\nContoh: .ban 6282361160044'

  let who = m.mentionedJid[0] 
    ? m.mentionedJid[0] 
    : m.quoted 
      ? m.quoted.sender 
      : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'

  if (!global.db.data.users[who]) {
    throw 'User tidak ditemukan di database!'
  }

  global.db.data.users[who].banned = true
  m.reply(`✅ Berhasil mem-ban ${await conn.getName(who)}. User ini tidak akan bisa menggunakan bot di mana pun sampai di-unban.`)
}

handler.help = ['ban']
handler.tags = ['owner']
handler.command = /^ban$/i
handler.owner = true

module.exports = handler