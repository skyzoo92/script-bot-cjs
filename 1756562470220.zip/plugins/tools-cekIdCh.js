let handler = async (m, { conn, text, usedPrefix, command }) => {
    let idch, tipe = 'invite';

    // Ambil ID channel dari reply jika dari channel (direct atau forwarded)
    if (m.quoted?.key?.remoteJid?.endsWith('@newsletter')) {
        idch = m.quoted.key.remoteJid.split('@')[0];
        tipe = 'jid';
    }
    if (!idch) {
        try {
            let quoted = await m.getQuotedObj();
            let forwarded = quoted?.msg?.contextInfo?.forwardedNewsletterMessageInfo;
            if (forwarded?.newsletterJid) {
                idch = forwarded.newsletterJid.split('@')[0];
                tipe = 'jid';
            }
        } catch (e) {
            console.error('[ERROR getQuotedObj]:', e);
        }
    }

    // Ambil ID dari link jika tidak ada dari reply
    if (!idch) {
        if (!text) throw `*• Example :* ${usedPrefix + command} *[url channel]*\nAtau reply langsung / diteruskan dari channel.`;
        let urls = extractUrls(text);
        for (let url of urls) {
            idch = getIdChannel(url);
            if (idch) {
                tipe = 'invite';
                break;
            }
        }
    }

    if (!idch) throw `ID channel tidak ditemukan. Pastikan link atau reply berasal dari channel WhatsApp.`;

    m.reply(info.wait); // gunakan pesan loading jika kamu punya, misal: 'Tunggu sebentar...'

    try {
        let finalId = tipe === 'jid' ? `${idch}@newsletter` : idch;
        let json = await conn.newsletterMetadata(tipe, finalId);

        let previewUrl = json.preview;
        let nyaww;

        try {
            if (previewUrl && /^https?:\/\//i.test(previewUrl)) {
                let file = await conn.getFile(previewUrl);
                nyaww = file.data;
            } else {
                nyaww = global.thumb;
            }
        } catch (e) {
            console.error('[ERROR getFile preview]:', e);
            nyaww = global.thumb;
        }

        let infoText = "*乂 N E W S L E T T E R - I N F O*\n\n" +
                       Object.entries(json).map(([a, b]) => `- *${capitalize(a)}* : ${b}`).join("\n");

        new Button()
            .setBody(infoText)
            .setFooter(info.wm)
            .setImage(nyaww)
            .addCopy("Copy Id Ch", json.id)
            .run(m.chat, conn, m);

    } catch (e) {
        throw `Gagal mengambil data channel: ${e.message}`;
    }
};

handler.help = ["ci"].map(a => a + " *[url channelwa]* atau reply pesan dari channel");
handler.tags = ["tools"];
handler.command = /^(ci|channelinfo)$/i;

module.exports = handler;

// ===== Helper Functions =====

function extractUrls(text) {
    const urlRegex = /https?:\/\/[^\s]+/g;
    return text.match(urlRegex) || [];
}

function getIdChannel(url) {
    const regex = /channel\/([^\/]+)/;
    const match = url.match(regex);
    return match ? match[1] : null;
}

function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}