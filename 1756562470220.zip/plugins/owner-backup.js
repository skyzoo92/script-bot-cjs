const fs = require('fs')
const {execSync} = require('child_process')

let handler = async (m, { conn, args, usedPrefix }) => {
    switch (args[0]) {
        case 'all': {
            try {
                m.reply('📦 Sedang mengumpulkan semua file untuk backup...')

                const ls = execSync("ls").toString().split("\n").filter(file =>
                    file !== "node_modules" &&
                    file !== "package-lock.json" &&
                    file !== "yarn.lock" &&
                    file !== ""
                )

                console.log("🗂️ File yang akan dibackup:", ls)

                const escapedFiles = ls.map(file => `"${file}"`).join(" ")
                execSync(`zip -r Backup.zip ${escapedFiles}`)

                if (!fs.existsSync('./Backup.zip')) {
                    return m.reply('❌ File ZIP tidak ditemukan, backup gagal.')
                }

                await conn.sendMessage(m.sender, {
                    document: fs.readFileSync('./Backup.zip'),
                    mimetype: "application/zip",
                    fileName: `Backup ${date}.zip`,
                })

                execSync("rm -rf Backup.zip")
                m.reply('✅ Backup selesai, file berhasil dikirim ke owner.')
            } catch (err) {
                console.error(err)
                m.reply('⚠️ Terjadi kesalahan saat proses backup.')
            }
            break
        }

        case 'auto': {
            if (global.set?.autobackup) return m.reply('ℹ️ Auto Backup sudah aktif sebelumnya.')
            global.settings.autobackup = true
            m.reply('✅ Auto Backup berhasil diaktifkan!')
            break
        }

        case 'session': {
            await conn.sendMessage(m.chat, {
                document: fs.readFileSync('./session'),
                mimetype: 'application/json',
                fileName: 'creds.json'
            }, { quoted: m })
            break
        }

        case 'database': {
            try {
                const dbPath = './database.json'
                if (!fs.existsSync(dbPath)) {
                    console.log('❌ File database tidak ditemukan.')
                    return
                }

                const buffer = fs.readFileSync(dbPath)
                const tanggal = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })

                for (const no of global.staff.nomorown) {
                    const jid = staff.nomorown + '@s.whatsapp.net'
                    const quoted = {
                        key: {
                            fromMe: false,
                            participant: '0@s.whatsapp.net',
                            remoteJid: jid,
                        },
                        message: {
                            conversation: `✅ Backup Berhasil dikirim pada ${tanggal}`
                        }
                    }

                    await conn.sendMessage(jid, {
                        document: buffer,
                        fileName: `database-${tanggal.replace(/[^\d]/g, '-')}.json`,
                        mimetype: 'application/json',
                        caption: `📦 *Backup Berhasil*\n📅 ${tanggal}\n\nFile database.json telah berhasil dibackup.`
                    }, { quoted })
                }

                console.log(`✅ Auto backup sukses dikirim ke ${global.owner.length} owner.`)
            } catch (err) {
                console.error('❌ Gagal auto backup:', err)
            }
            break
        }

        default: {
            let text = `✨ Gunakan salah satu perintah berikut:\n
- ${usedPrefix}backup auto
- ${usedPrefix}backup all
- ${usedPrefix}backup database
- ${usedPrefix}backup session`

            let buttons = [
                {
                    buttonId: "backup",
                    buttonText: { displayText: "🗂️ Gunakan Perintah Backup" },
                    type: 4,
                    nativeFlowInfo: {
                        name: "single_select",
                        paramsJson: JSON.stringify({
                            title: "💾 Pilih Perintah Backup yang Tersedia",
                            sections: [
                                {
                                    title: "Daftar Perintah Backup",
                                    rows: [
                                        { title: "📦 Backup Semua", description: "Backup semua data sekaligus", id: `${usedPrefix}backup all` },
                                        { title: "🕒 Backup Otomatis", description: "Mengaktifkan backup otomatis", id: `${usedPrefix}backup auto` },
                                        { title: "💼 Backup Session", description: "Backup file session bot", id: `${usedPrefix}backup session` },
                                        { title: "🗃️ Backup Database", description: "Backup file database bot", id: `${usedPrefix}backup database` },
                                    ],
                                },
                            ],
                        }),
                    },
                },
            ]

            await conn.sendMessage(
                m.chat,
                {
                    text,
                    footer: `© Powered by ${global.staff?.nameown || 'Hydra'}`,
                    buttons,
                    headerType: 1,
                    viewOnce: true,
                },
                { quoted: m }
            )
        }
    }
}

handler.help = ['backup [all|auto|session|database]']
handler.tags = ['owner']
handler.command = /^backup$/i
handler.owner = true

module.exports = handler