const { generateWAMessageFromContent, prepareWAMessageMedia, proto } = require('@kelvdra/bails')
const hydra = require('@kelvdra/scraper')

var handler = async (m, { conn }) => {
  let res = await hydra.ppcp()
  let couple = res.results

  let msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          contextInfo: {
            mentionedJid: [m.sender],
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: '120363298688453806@newsletter',
              newsletterName: 'Powered By Hydra',
              serverMessageId: -1
            },
            businessMessageForwardInfo: {
              businessOwnerJid: conn.decodeJid(conn.user.id)
            },
            forwardingScore: 256,
            externalAdReply: {
              title: 'DCODEKEMII',
              thumbnailUrl: 'https://telegra.ph/file/a6f3ef42e42efcf542950.jpg',
              sourceUrl: link.saluran,
              mediaType: 2,
              renderLargerThumbnail: false
            }
          },
          body: proto.Message.InteractiveMessage.Body.create({
            text: "Ini Kak",
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: '',
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            hasMediaAttachment: false
          }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.create({
            cards: [
              {
                body: proto.Message.InteractiveMessage.Body.create({
                  text: ''
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({}),
                header: proto.Message.InteractiveMessage.Header.create({
                  title: `\`MALE\`\n`,
                  hasMediaAttachment: true,
                  ...(await prepareWAMessageMedia({ image: { url: couple.cowo } }, { upload: conn.waUploadToServer }))
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                  buttons: []
                })
              },
              {
                body: proto.Message.InteractiveMessage.Body.create({
                  text: ''
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({}),
                header: proto.Message.InteractiveMessage.Header.create({
                  title: `\`FEMALE\`\n`,
                  hasMediaAttachment: true,
                  ...(await prepareWAMessageMedia({ image: { url: couple.cewe } }, { upload: conn.waUploadToServer }))
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                  buttons: []
                })
              }
            ]
          })
        })
      }
    }
  }, { userJid: m.chat, quoted: m })

  conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })
}

handler.help = ['ppcouple']
handler.tags = ['internet']
handler.command = /^(ppcp|ppcouple)$/i
handler.limit = 4

module.exports = handler