async function before(m) {
  const chat = global.db.data.chats[m.chat];
  if (!chat || !chat.ngetik) return;
  const prefix = global.prefix;
  const commands = Object.values(global.features)
    .flatMap(plugin => plugin.command || [])
    .filter(cmd => cmd);
  const isCommand = commands.some(cmd =>
    cmd instanceof RegExp ? cmd.test(m.text) : prefix.test(m.text) && m.text.slice(1).startsWith(cmd)
  );
  if (isCommand) {
    await this.sendPresenceUpdate('composing', m.chat);
  }
}

module.exports = { before }