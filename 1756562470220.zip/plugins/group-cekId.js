const { generateWAMessageFromContent, prepareWAMessageMedia, proto, getGroupInviteInfo } = require('@kelvdra/bails')

let handler = async (m, { conn, args, groupMetadata }) => {
  let groupId
  if (args[0]) {
    // Cek apakah input adalah link grup
    let regex = /https?:\/\/chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i
    let [_, code] = args[0].match(regex) || []
    if (!code) return m.reply('Link grup tidak valid.')

    try {
      let res = await conn.groupGetInviteInfo(code)
      groupId = res.id
    } catch (e) {
      return m.reply('Gagal mengambil info grup. Pastikan link valid dan bot belum dikeluarkan.')
    }
  } else {
    if (!m.isGroup) return m.reply('Fitur ini hanya bisa dipakai di grup atau dengan link grup.')
    groupId = groupMetadata.id
  }

  let msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: "Tekan Button Di Bawah, Otomatis Ke Copy",
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: ""
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            hasMediaAttachment: false,
            ...await prepareWAMessageMedia({ image: { url: logo.rapthalia} }, { upload: conn.waUploadToServer })
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                name: "cta_copy",
                buttonParamsJson: `{\"display_text\":\"copy otomatis\",\"id\":\"gc\",\"copy_code\":\"${groupId}\"}`
              },
            ],
          })
        })
      }
    }
  }, { quoted: m })

  await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

handler.help = ['cekid [link]']
handler.tags = ['group']
handler.command = /^(cekidgc|idgc|gcid|cekid)$/i

module.exports = handler