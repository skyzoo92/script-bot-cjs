const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = require('@kelvdra/bails')

let handler = async (m, { conn, usedPrefix, command, text }) => {
    let input = `[❗] Masukan Salah\n\nContoh: /${usedPrefix + command} halo`;
    if (!text) return m.reply(input);

    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender;
    let pp = await conn.profilePictureUrl(who, 'image').catch(_ => 'https://files.catbox.moe/gqs7oz.jpg');
    
    let cap = `✨ *Menu Pilihan Brat* ✨

📌 *Teks:* ${text}
📅 *Tanggal:* ${date}

🔍 Pilih tipe tampilan:
- Gambar
- Video
- Anime

🔥 Rapthalia Kawai By Hydra 🔥`;
    conn.sendMessage(m.chat, {
  image: { url: pp },
  caption: cap,
  footer: "Rapthalia Kawai By Hydra",
  contextInfo: {
            externalAdReply: {
                title: '',
                thumbnailUrl: pp,
                sourceUrl: `https://wa.me/${who.split`@`[0]}`,
                mediaType: 1,
                renderLargerThumbnail: false,
                mentionedJid: [m.sender]
            }
        },
  buttons: [
  {
    buttonId: '.totalbrat',
    buttonText: {
      displayText: 'TOTAL PENGGUNAAN BRAT'
    },
    type: 1,
  },
  {
    buttonId: 'action',
    buttonText: {
      displayText: 'ini pesan interactiveMeta'
    },
    type: 4,
    nativeFlowInfo: {
      name: 'single_select',
      paramsJson: JSON.stringify({
        title: 'CLICK',
        sections: [
          {
            title: 'Pilih Type Brat',
            highlight_label: 'Populer',
            rows: [
              {
                header: 'BRAT GAMBAR',
                title: 'BRAT TEKS DIAM',
                description: 'DESCRIPTION',
                id: `.bratimg ${text}`,
              },
              {
                header: 'BRAT VIDEO',
                title: 'BRAT TEKS GERAK',
                description: 'DESCRIPTION',
                id: `.bratvid ${text}`,
              },
              {
                header: 'BRAT ANIME',
                title: 'BRAT KARAKTER ANIME',
                description: 'DESCRIPTION',
                id: `.animbrat ${text}`,
              },
            ],
          },
        ],
      }),
    },
  },
  ],
  headerType: 1,
  viewOnce: true
}, { quoted: m });
}

handler.help = ["brat"];
handler.tags = ["sticker"];
handler.command = /^(brat)$/i;
handler.limit = 4;
handler.group = true
module.exports = handler