const hydra = require('@kelvdra/scraper')

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Masukan URL!\n\nContoh:\n${usedPrefix + command} https://vt.tiktok.com/ZS2pufVMk/`;    

    m.reply(info.wait);  
    try {
        const response = await hydra.ttdl(`${text}`);
        const res = response.result;

        if (!res || !res.data) throw "Gagal mendapatkan data video.";

        // Ambil URL video dengan type 'nowatermark_hd'
        let videoUrl = res.data.find(v => v.type === "nowatermark_hd")?.url;
        if (!videoUrl) throw "Video HD tanpa watermark tidak ditemukan.";

        let title = res.title || "Tiktok Video";
        let audioUrl = res.music_info?.url || null;

        let caption = `*Title:* ${title}`;

        // Kirim video
        await conn.sendMessage(m.chat, { 
            video: { url: videoUrl }, 
            mimetype: 'video/mp4',
            fileName: `${title}.mp4`,
            caption: caption
        }, { quoted: m });

        // Jika ada audio, kirim juga
        if (audioUrl) {
            let aud = {
                audio: { url: audioUrl },
                mimetype: 'audio/mp4',
                fileName: `${title}.mp3`,
            };
            await conn.sendMessage(m.chat, aud, { quoted: m });
        }

    } catch (error) {
        console.error(error);
        m.reply("Terjadi kesalahan saat mengambil video TikTok.");
    }
};

handler.help = ['tiktokhd'];
handler.command = ["tthd","tiktokhd"];
handler.tags = ['downloader'];
handler.register = true
handler.premium = true;

module.exports = handler