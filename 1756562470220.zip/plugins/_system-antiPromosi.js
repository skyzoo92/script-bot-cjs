const handler = m => m;

handler.before = async function(m, { user, isBotAdmin, isAdmin }) {
  if ((m.isBaileys && m.fromMe) || m.fromMe || !m.isGroup) return true;
  
  const chat = global.db.data.chats[m.chat];
    const text = m.text.toLowerCase();

  if (chat.antiPromosi) {
  if ((text.includes('panel') || text.includes('akun') || text.includes('join') || text.includes('diskon') || text.includes('promo') || text.includes('minat') || text.includes('pm') || text.includes('testi') || text.includes('list') || text.includes('ready') || text.includes('open'))) {
    await m.reply(`*「 DETECTED PROMOTION 」*\n\nTerdeteksi *${await conn.getName(m.sender)}* Sedang promosi🤦‍♀️\n\nMaaf pesan anda akan di hapus`);
    
    if (isAdmin) return m.reply('*Admin mah bebas ye kan.. 😏*');
    if (!isBotAdmin) return m.reply('*Yah Gk Bisa Hapus, Bot Bukan Admin*');
  await conn.sendMessage(m.chat, { delete: m.key });
}
}
  
  return true;
};

module.exports = handler

 function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}