let handler = async (m, { conn, command, args, usedPrefix }) => {
  try {
    let user = global.db.data.users[m.sender];

    // Inisialisasi semua resource biar tidak NaN
    let resources = ['pickaxe', 'pedang', 'fishingrod', 'wood', 'iron', 'string', 'rock', 'emerald', 'diamond', 'money', 'armor', 'atm', 'sword', 'pickaxedurability', 'sworddurability', 'fishingroddurability', 'armordurability', 'fullatm', 'confirmDeleteATM'];
    for (let res of resources) user[res] = user[res] || 0;

    const recipes = {
      pickaxe: {
        bahan: { wood: 10, iron: 5, rock: 5, string: 20 },
        hasil: { pickaxe: 1, pickaxedurability: 40 },
        nama: "Pickaxe ⛏️",
      },
      sword: {
        bahan: { wood: 10, iron: 15 },
        hasil: { sword: 1, sworddurability: 40 },
        nama: "Sword ⚔️",
      },
      fishingrod: {
        bahan: { wood: 10, iron: 2, string: 20 },
        hasil: { fishingrod: 1, fishingroddurability: 40 },
        nama: "Fishing Rod 🎣",
      },
      armor: {
        bahan: { iron: 30, emerald: 1, diamond: 5 },
        hasil: { armor: 1, armordurability: 50 },
        nama: "Armor 🥼",
      },
      atm: {
        bahan: { emerald: 3, diamond: 6, money: 10000 },
        hasil: { atm: 1, fullatm: 5000000 },
        nama: "ATM 💳",
      },
    };

    if (/craft|crafting|chant/i.test(command)) {
      let item = (args[0] || '').toLowerCase();
      if (!item || !(item in recipes)) {
        return m.reply(`▧ Pickaxe ⛏️\n▧ Sword ⚔️\n▧ Fishing Rod 🎣\n▧ Armor 🥼\n▧ ATM 💳\n\nKetik: *${usedPrefix}craft (nama)*\nContoh: *${usedPrefix}craft sword*`);
      }

      if (user[item] > 0) return m.reply(`Kamu sudah memiliki ${recipes[item].nama}`);

      let bahanKurang = [];
      for (let bahan in recipes[item].bahan) {
        if (user[bahan] < recipes[item].bahan[bahan]) {
          bahanKurang.push(`${recipes[item].bahan[bahan]} ${bahan}`);
        }
      }
      if (bahanKurang.length) {
        return m.reply(`Barang tidak cukup untuk membuat ${recipes[item].nama}!\n\nKamu butuh:\n${bahanKurang.map(v => '• ' + v).join('\n')}`);
      }

      // Bahan cukup, crafting!
      for (let bahan in recipes[item].bahan) {
        user[bahan] -= recipes[item].bahan[bahan];
      }
      for (let hasil in recipes[item].hasil) {
        user[hasil] = (user[hasil] || 0) + recipes[item].hasil[hasil];
      }
      m.reply(`Sukses membuat 1 ${recipes[item].nama}`);
    }

    else if (/deleteatm/i.test(command)) {
      if (user.atm === 0) {
        return m.reply(`Kamu belum memiliki *💳ATM*, tidak ada yang bisa dihapus.`);
      }
      if (!user.confirmDeleteATM) {
        user.confirmDeleteATM = true;
        return m.reply(`⚠️ Kamu yakin ingin menghapus ATM? Semua level dan kapasitas akan hilang!\nKetik *${usedPrefix}deleteatm* lagi untuk konfirmasi.`);
      }
      user.atm = 0;
      user.fullatm = 0;
      user.confirmDeleteATM = false;
      m.reply(`ATM kamu berhasil dihapus! Jika ingin membuat lagi, ketik *${usedPrefix}craft atm*`);
    }

  } catch (err) {
    m.reply("Error:\n\n" + err.stack);
  }
};

handler.help = ['craft', 'deleteatm'];
handler.tags = ['rpg'];
handler.command = /^(craft|crafting|chant|deleteatm)$/i;
handler.register = true;
module.exports = handler;