const handler = async (m, { text }) => {
  if (!text) {
    return m.reply("Masukan query");
  }

  m.react("💬");

  try {
    const response = await hydra.askAI(text, "gpt-4.1");
    const result = response.results

    if (!result) {
      throw new Error("Tidak ada jawaban dari API.");
    }
    await conn.sendMessage(m.chat, {
        text: result,
        contextInfo: {
            externalAdReply: {
                title: "META AI",
                thumbnailUrl: "https://files.catbox.moe/ho9mxx.jpg",
                sourceUrl: "https://www.meta.ai/",
                mediaType: 1,
                renderLargerThumbnail: false,
                mentionedJid: [m.sender]
            }
        }
    }, { quoted: m });
       m.react("")
  } catch (error) {
    console.error("Terjadi kesalahan:", error);
    m.reply("Terjadi kesalahan saat mengakses API.");
    m.react("❌")
  }
};

handler.help = ["metaai"];
handler.tags = ["ai"];
handler.command = /^(metaai|aimeta)$/i;
handler.limit = 4
module.exports = handler