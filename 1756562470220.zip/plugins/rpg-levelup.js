const levelling = require('../function/levelling.js')
const moment = require('moment-timezone')
const canvafy = require('canvafy')
const fs = require('fs')

let handler = async (m, { conn }) => {
    try {
        let user = global.db.data.users
        let data = user[m.sender]

        if (!levelling.canLevelUp(data.level, data.exp, 38)) {
            let { min, xp, max } = levelling.xpRange(data.level, 38)
            return m.reply(`
Level ${data.level} 📊
*${data.exp - min} / ${xp}*
Kurang *${max - data.exp}* lagi! ✨
`.trim())
        }

        let before = data.level * 1
        while (levelling.canLevelUp(data.level, data.exp, 38)) data.level++

        if (before !== data.level) {
            let str = `
*🎉 C O N G R A T S 🎉*
*${before}* ➔ *${data.level}* [ *${data.role}* ]

*Note:* _Semakin sering berinteraksi dengan bot, semakin tinggi level kamu_
`.trim()

            let member = Object.keys(user).filter(v => user[v].level > 0).sort((a, b) => user[b].level - user[a].level)
            let { min, xp, max } = levelling.xpRange(data.level, 38)
            const pp = await conn.profilePictureUrl(m.sender, 'image').catch(_ => fs.readFileSync('./src/avatar_contact.png'))
            const name = data.registered ? data.name : await conn.getName(m.sender)

            try {
                let img = await canvafyRank(pp, name, "online", data.level, member.indexOf(m.sender), data.exp - min, xp)
                await conn.sendFile(m.chat, img, 'levelup.jpg', str, m)
            } catch (e) {
                let img = await canvafyRank(pp, name, "online", data.level, member.indexOf(m.sender), data.exp - min, xp)
                await conn.sendFile(m.chat, img, 'levelup.jpg', str, m)
            }
        }
    } catch (e) {
        throw e
    }
}

handler.help = ['levelup']
handler.tags = ['rpg']
handler.command = /^level(|up)$/i

module.exports = handler

async function canvafyRank(avatar, username, status, level, rank, cxp, rxp) {
    const background = [
        "https://pomf2.lain.la/f/tjkwx2ro.jpg",
        "https://pomf2.lain.la/f/unw8fo6l.jpg",
        "https://pomf2.lain.la/f/kw2o7unm.jpg",
        "https://pomf2.lain.la/f/2kjrz5ho.jpg",
        "https://pomf2.lain.la/f/g3d4id5i.jpg"
    ]
    const bg = Array.prototype.getRandom ? background.getRandom() : background[Math.floor(Math.random() * background.length)]

    const rankBuffer = await new canvafy.Rank()
        .setAvatar(avatar)
        .setBackground("image", bg)
        .setUsername(username)
        .setBorder("#FF00F1")
        .setBarColor("#FF00F1")
        .setStatus(status)
        .setLevel(level)
        .setRank(rank + 1)
        .setCurrentXp(cxp)
        .setRequiredXp(rxp)
        .build()

    return rankBuffer
}