let handler = async (m, { conn, isOwner, text, isAdmin }) => {
  let who
  if (m.isGroup) {
    if (!(isAdmin || isOwner)) {
      global.dfail('admin', m, conn)
      throw false
    }
    who = m.chat
  } else {
    if (!isOwner) {
      global.dfail('owner', m, conn)
      throw false
    }
    who = m.chat
  }
  try {
    global.db.data.chats[who].isBanned = true
    m.reply(`Berhasil Ban Chat! ${await conn.user.name} tidak aktif di chat ini.`)
  } catch (e) {
    throw `Gagal membanned chat!`
  }
}
handler.help = ['banchat']
handler.tags = ['owner']
handler.command = /^banchat?$/i
module.exports = handler