const hydra = require("@kelvdra/scraper");

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) {
        throw m.reply(`[❗] Masukkan query!\n\nContoh: ${usedPrefix + command} jj furina`);
    }

    m.reply('⏳ Tunggu sebentar...');
    try {
        const data = await hydra.tiktoks(text);

        if (!data || !Array.isArray(data.results) || data.results.length === 0) {
            throw 'Tidak ada hasil ditemukan.';
        }

        let listMessage = `*🫧 TikTok - Search*\nHasil pencarian untuk: *${text}*\n\n`;
        data.results.forEach((video, index) => {
            listMessage += `${index + 1}. ${video.title}\n`;
        });
        listMessage += `\n> Balas pesan ini dengan nomor untuk memilih video.`;

        conn.sendMessage(m.chat, {
            text: listMessage,
            contextInfo: {
                externalAdReply: {
                    title: `Tiktok Search: ${text}`,
                    thumbnailUrl: data.results[0].cover || '',
                    sourceUrl: '',
                    mediaType: 1,
                    renderLargerThumbnail: false,
                    mentionedJid: [m.sender]
                }
            }
        }, { quoted: m });

        // Simpan hasil untuk sesi chat ini
        conn.data = conn.data || {};
        conn.data[m.chat] = data.results;

        // Daftarkan handler balasan jika belum
        if (!conn.eventRegistered) {
            conn.eventRegistered = true;
            conn.ev.on('messages.upsert', videoHandler);
        }

    } catch (err) {
        console.error(err);
        m.reply(`[❗] Terjadi kesalahan:\n${err}`);
    }
};

const videoHandler = async (chatUpdate) => {
    const msg = chatUpdate.messages[0];
    if (!msg.message) return;

    const type = Object.keys(msg.message)[0];
    if (type !== 'conversation' && type !== 'extendedTextMessage') return;

    const body = (type === 'conversation') ? msg.message.conversation : msg.message.extendedTextMessage.text;
    if (msg.key.fromMe) return;

    const chatId = msg.key.remoteJid;
    if (!conn.data || !conn.data[chatId]) return;

    const index = parseInt(body.trim()) - 1;
    const videos = conn.data[chatId];

    if (isNaN(index) || index < 0 || index >= videos.length) {
        conn.sendMessage(chatId, { text: 'Nomor tidak valid. Silakan balas dengan nomor yang benar.' });
    } else {
        const selected = videos[index];
        const caption = `*🫧 TikTok - Result*\n🎬 Judul: ${selected.title}`;

        // Kirim preview thumbnail
        await conn.sendMessage(chatId, {
            image: { url: selected.cover },
            caption: `🔍 *Preview Video*`
        });

        // Kirim video (gunakan play / wmplay)
        await conn.sendMessage(chatId, {
            video: selected.play,
            caption
        }, { quoted: msg });
    }

    // Hapus data setelah dipilih
    delete conn.data[chatId];
    if (Object.keys(conn.data).length === 0) {
        conn.ev.off('messages.upsert', videoHandler);
        conn.eventRegistered = false;
    }
};

handler.help = ['ttsearch'];
handler.tags = ['downloader'];
handler.command = /^(ttsearch|tiktoksearch)$/i;
handler.limit = 3;
handler.register = true;

module.exports = handler;