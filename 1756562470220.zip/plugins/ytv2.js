const hydra = require('@kelvdra/scraper');

const handler = async (m, { args, conn, text }) => {
  if (!args[0]) {
    return m.reply('Masukkan URL YouTube!\nContoh: .ytmp4 https://youtube.com/watch?v=gdauR-YQkAQ');
  }

  const url = args[0];
  try {
 conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });


    const json = await hydra.ytmp4(url);

    if (!json.status) {
      return m.reply('Gagal mengambil video. Pastikan URL valid.');
    }

    await conn.sendMessage(m.chat, {
      video: { url: json.download.url },
      caption: ``,
    }, { quoted: m });
    m.react("")
  } catch (e) {
    console.error(e);
    m.reply('Terjadi kesalahan saat memproses permintaan.\n' + e);
  }
};

handler.command = ['ytv2'];
handler.help = ['ytv2 <URL>'];
handler.tags = ['downloader'];
handler.limit = 3
module.exports = handler