const { join } = require('path')
const { readdirSync } = require('fs')

let handler = async (m) => {
    let pluginsPath = join(__dirname, '../plugins/')
    let files = readdirSync(pluginsPath).filter(file => file.endsWith('.js') || file.endsWith('.cjs'))

    if (files.length === 0) return m.reply('📂 Folder *plugins* kosong.')

    let list = files.map((v, i) => `📄 ${i + 1}. ${v}`).join('\n')
    m.reply(`📦 *Daftar file plugin:*\n\n${list}\n\n📁 Total: *${files.length}* file`)
}

handler.help = ['listplug']
handler.tags = ['owner']
handler.command = /^listplug$/i
handler.mods = true

module.exports = handler