const fs = require('fs');
const fetch = require('node-fetch');
let handler = async (m, { conn }) => { 

         let caption = `*Mʏ Gʀᴏᴜᴘ Oғғɪᴄɪᴀʟ* ${link.sgc}`;
    conn.sendMessage(m.chat, {
     text: `${caption}`,
      contextInfo: {
                externalAdReply: {
                    title: "R A P T H A L I A  M U L T I D E V I C E",
                    thumbnailUrl: logo.rapthalia,
                    sourceUrl: link.sgc,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    mentionedJid: [m.sender]
                     }}}, { quoted: fkon })
 }
handler.help = ['gcbot'];
handler.tags = ['main'];
handler.command = /^(gcbot|groupbot|botgc|botgroup|gcrapthalia|grouprapthalia)$/i;
module.exports = handler;