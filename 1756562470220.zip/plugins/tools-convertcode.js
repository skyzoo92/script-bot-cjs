let handler = async (m, { conn, text, command }) => {
    let codeToConvert = text || (m.quoted && m.quoted.text)

    if (!codeToConvert) throw `Masukkan atau reply kode yang ingin diubah`

    let result
    switch (command) {
        case 'toesm':
            result = convertCJStoESM(codeToConvert)
            break
        case 'tocjs':
            result = convertESMtoCJS(codeToConvert)
            break
        default:
            throw `Perintah tidak dikenal`
    }

    await m.reply(result)
}

handler.help = ['toesm <kode>', 'tocjs <kode>']
handler.tags = ['tools']
handler.command = /^(toesm|tocjs)$/i
handler.limit = true

module.exports = handler

function convertCJStoESM(code) {
  code = code.replace(/const\s+([a-zA-Z0-9_$]+)\s*=\s*require\(['"]([^'"]+)['"]\)/g, 'import $1 from "$2"')
  code = code.replace(/const\s*{\s*([^}]+)\s*}\s*=\s*require\(['"]([^'"]+)['"]\)/g, 'import { $1 } from "$2"')
  code = code.replace(/module\.exports\s*=\s*([a-zA-Z0-9_]+)/g, 'export default $1')
  code = code.replace(/module\.exports\s*=\s*async\s*function\s*([a-zA-Z0-9_]*)\(/g, (_, name) => {
    return name ? `export default async function ${name}(` : `export default async function(`
  })
  code = code.replace(/module\.exports\s*=\s*function\s*([a-zA-Z0-9_]*)\(/g, (_, name) => {
    return name ? `export default function ${name}(` : `export default function(`
  })
  code = code.replace(/exports\.([a-zA-Z0-9_]+)\s*=/g, 'export const $1 =')

  return code
}


function convertESMtoCJS(code) {
  code = code.replace(/import\s+{([^}]+)}\s+from\s+['"]([^'"]+)['"]/g, (_, imports, from) => {
    return `const {${imports.trim()}} = require('${from}')`
  })
  code = code.replace(/import\s+([a-zA-Z0-9_$]+)\s+from\s+['"]([^'"]+)['"]/g, (_, name, from) => {
    return `const ${name} = require('${from}')`
  })
  code = code.replace(/export\s+default\s+async\s+function\s+([a-zA-Z0-9_]+)\(/g, 'module.exports = async function $1(')
  code = code.replace(/export\s+default\s+function\s+([a-zA-Z0-9_]+)\(/g, 'module.exports = function $1(')
  code = code.replace(/export\s+async\s+function\s+([a-zA-Z0-9_]+)\(/g, 'async function $1(')
  code = code.replace(/export\s+function\s+([a-zA-Z0-9_]+)\(/g, 'function $1(')
  code = code.replace(/export\s+const\s+([a-zA-Z0-9_]+)\s+=/g, 'const $1 =')
  code = code.replace(/export\s+default\s+([a-zA-Z0-9_]+)/g, 'module.exports = $1')
  const exportMatches = code.match(/function\s+([a-zA-Z0-9_]+)\(/g)
  code = code.replace(/const\s*{([^}]+)}\s*=\s*\(await\s*import\(['"]([^'"]+)['"]\)\)\.default/g,
  (match, vars, lib) => {
    const libVar = lib.split('/').pop().replace(/[^a-zA-Z]/g, '') || 'lib'
    return `const ${libVar} = require("${lib}")\nconst {${vars.trim()}} = ${libVar}`
  })
  if (exportMatches) {
    const exportNames = exportMatches.map(m => m.match(/function\s+([a-zA-Z0-9_]+)\(/)[1])
    if (exportNames.length && !code.includes('module.exports')) {
      code += `\n\nmodule.exports = { ${exportNames.join(', ')} }`
    }
  }

  return code
}