const fs = require('fs')
const path = require('path')

let handler = async (m, { conn, isROwner, usedPrefix, command, text }) => {
    let args = text.split(' ')
    if (args.length < 2) throw `Format salah!\n\nGunakan:\n${usedPrefix + command} <path_lama>|<nama_baru>\n\nContoh:\n${usedPrefix + command} lib/hydra.js|hydra-new.js`

    let oldPath = args[0] // Path lama, bisa termasuk folder
    let newName = args.slice(1).join(' ') // Nama baru bisa memiliki spasi

    // Pastikan path lama valid
    if (!fs.existsSync(oldPath)) throw 'File tidak ditemukan!'

    // Ambil direktori dari path lama
    let dir = path.dirname(oldPath)
    let newPath = path.join(dir, newName) // Buat path baru di folder yang sama

    // Validasi nama baru agar tidak mengandung karakter berbahaya
    if (!/^[\w.-]+$/.test(path.basename(newName))) throw 'Nama file tidak valid!'

    try {
        fs.renameSync(oldPath, newPath)
        m.reply(`✅ Berhasil mengganti nama file:\n\n📂 *Dari:* ${oldPath}\n📂 *Menjadi:* ${newPath}`)
    } catch (e) {
        m.reply(`❌ Gagal mengganti nama file: ${e.message}`)
    }
}

handler.help = ['renamefile'].map(v => v + ' <path_lama> <nama_baru>')
handler.tags = ['owner']
handler.command = /^(renamefile|rename|rfile)$/i
handler.rowner = true

module.exports = handler