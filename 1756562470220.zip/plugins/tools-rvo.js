const handler = async (m, {
  conn
}) => {
	if (!m.quoted) throw m.reply(`Reply to view once message`)
	if (!m.quoted.viewOnce) throw m.reply(`This is not a view once message`)
    let msg = m.quoted;
    let media = await msg.download();
    conn.sendFile(m.chat, media, 'media.mp4', msg.caption || '', m, true)  
  };
handler.help = ['readviewonce']
handler.tags = ['tools']
handler.command = /^readviewonce|rvo/i
module.exports = handler