const PhoneNumber = require('awesome-phonenumber')
const fetch = require('node-fetch')
const moment = require('moment-timezone')
let {
    proto,
    prepareWAMessageMedia,
    generateWAMessageFromContent
} = require('@kelvdra/bails')
let handler = async (m, { conn }) => {
    let d = new Date(new Date + 3600000)
    let locale = 'id'
    // d.getTimeZoneOffset()
    // Offset -420 is 18.00
    // Offset    0 is  0.00
    // Offset  420 is  7.00
    let weton = ['Pahing',
        'Pon',
        'Wage',
        'Kliwon',
        'Legi'][Math.floor(d / 84600000) % 5]
    let week = d.toLocaleDateString(locale, {
        weekday: 'long'
    })
    let date = d.toLocaleDateString(locale, {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    })
    let wibh = moment.tz('Asia/Jakarta').format('HH')
    let wibm = moment.tz('Asia/Jakarta').format('mm')
    let wibs = moment.tz('Asia/Jakarta').format('ss')
    let wktuwib = `${wibh} H ${wibm} M ${wibs} S`
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0]: m.fromMe ? conn.user.jid: m.sender
    if (typeof db.data.users[who] == 'undefined') return m.reply('Pengguna tidak ada didalam data base')
    let pp = await conn.profilePictureUrl(who, 'image').catch(_ => 'https://files.catbox.moe/gqs7oz.jpg')
    let bio = await conn.fetchStatus(who).catch(_ => 'Tidak Ada Bio')
    let { role, premium, money, level, limit, exp, lastclaim, registered, regTime, age, gender, ras } = global.db.data.users[who]
    let username = conn.getName(who)
    let user = db.data.users[who]
    let name = `${user.registered ? user.name : conn.getName(who)}`
    if (!(who in global.db.data.users)) return m.reply(`User ${who} not in database`)
    let fkon = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: `status@broadcast` }: {} )}, message: { 'contactMessage': { 'displayName': name, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${name},;;;\nFN:${name},\nitem1.TEL;waid=${who.split('@')[0]}:${who.split('@')[0]}\nitem1.X-ABLabell:Ponsel\nEND:VCARD`, 'jpegThumbnail': pp, thumbnail: pp, sendEphemeral: true }}}
    let str = ` – *ɪɴғᴏ ᴜsᴇʀ*
    
┌ • *ᴜsᴇʀɴᴀᴍᴇ:* ${user.registered ? user.name : conn.getName(who)}
│ • *ᴜᴍᴜʀ:* ${user.registered ? age: ''}
│ • *ʙɪᴏ:* ${bio.status ? bio.status : bio}
│ • *ᴛᴀɢ:* @${who.replace(/@.+/, '')}
│ • *ɴᴏᴍᴏʀ:* ${PhoneNumber('+' + who.replace('@s.whatsapp.net', '')).getNumber('international')}
└ • *ʟɪɴᴋ:* https://wa.me/${who.split`@`[0]}

 – *sᴛᴀᴛᴜs:*   ${who.split`@`[0] == global.staff.nomorwa ? '🎗️ᴅᴇᴠᴇʟᴏᴘᴇʀ🎗️' : user.premiumTime >= 1 ? '👑ℙ𝕣𝕖𝕞𝕚𝕦𝕞👑' : user.level >= 1000 ? '🪖ᴇʟɪᴛᴇ ᴜsᴇʀ🪖' : '👤ғʀᴇᴇ ᴜsᴇʀ👤'}

 – *ʀᴘɢ ᴘʀᴏғɪʟᴇ*

┌ • *ʀᴏʟᴇ:* ${role}
│ • *ʟᴇᴠᴇʟ:* ${level}
└ • *ᴇxᴘ:* ${exp}
 
 – *ᴘʀᴇᴍɪᴜᴍ?*
 
┌ • *ᴘʀᴇᴍɪᴜᴍ:* ${user.premiumTime > 0 ? "☑️": "❌"} ${user.premiumTime > 0 ? `
│ • *ᴘʀᴇᴍɪᴜᴍᴛɪᴍᴇ:*
${clockString(user.premiumTime - new Date() * 1)}`: ''}
└ • *ʀᴇɢɪsᴛᴇʀᴇᴅ:* ${user.registered ? '☑️ ( ' + new Date(regTime) + ' )' : '❌'}
 
⻝ 𝗗𝗮𝘁𝗲: ${week} ${date}
⻝ 𝗧𝗶𝗺𝗲: ${wktuwib}`.trim()
    let msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: str
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: ""
          }),
          header: proto.Message.InteractiveMessage.Header.create({
          hasMediaAttachment: false,
          ...await prepareWAMessageMedia({ image: { url: pp } }, { upload: conn.waUploadToServer })
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "single_select",
                "buttonParamsJson": "{\"title\":\"Claim Points\",\"sections\":[{\"title\":\"WEEKLY AND MONTHLY\",\"highlight_label\":\"\",\"rows\":[{\"header\":\"Claim Weekly And Monthly Rewards\",\"title\":\"Claim Weekly Rewards\",\"description\":\"\",\"id\":\".weekly\"},{\"header\":\"Claim Monthly Rewards\",\"title\":\"Claim Monthly Rewards\",\"description\":\"\",\"id\":\".monthly\"}]},{\"title\":\"Games And Work Get Rewards\",\"highlight_label\":\"\",\"rows\":[{\"header\":\"Adventure ✈️\",\"title\":\"Adventure\",\"description\":\"\",\"id\":\".adv\"},{\"header\":\"Ngojek 🛵\",\"title\":\"Ngojek\",\"description\":\"\",\"id\":\".ojek\"},{\"header\":\"Taksi 🚕\",\"title\":\"Taksi\",\"description\":\"\",\"id\":\".taksi\"},{\"header\":\"Dokter 👨‍⚕\",\"title\":\"Dokter\",\"description\":\"\",\"id\":\".dokter\"},{\"header\":\"Petani 👨‍🌾\",\"title\":\"Petani\",\"description\":\"\",\"id\":\".Petani\"},{\"header\":\"Pedagang 🧔\",\"title\":\"Pedagang\",\"description\":\"\",\"id\":\".pedagang\"},{\"header\":\"Teacher 👨‍🏫\",\"title\":\"Teacher\",\"description\":\"\",\"id\":\".teacher\"}]}]}"
              },  
           ],
          })
        })
    }
  }
}, { quoted: m })

await conn.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}
handler.help = ['profile [@user]']
handler.tags = ['rpg']
handler.command = /^(profile|profil|me)$/i
module.exports = handler

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

function clockString(ms) {
    let ye = isNaN(ms) ? '--': Math.floor(ms / 31104000000) % 10
    let mo = isNaN(ms) ? '--': Math.floor(ms / 2592000000) % 12
    let d = isNaN(ms) ? '--': Math.floor(ms / 86400000) % 30
    let h = isNaN(ms) ? '--': Math.floor(ms / 3600000) % 24
    let m = isNaN(ms) ? '--': Math.floor(ms / 60000) % 60
    let s = isNaN(ms) ? '--': Math.floor(ms / 1000) % 60
    return ['┊ ', ye, ' *Years 🗓️*\n', '┊ ', mo, ' *Month 🌙*\n', '┊ ', d, ' *Days ☀️*\n', '┊ ', h, ' *Hours 🕐*\n', '┊ ', m, ' *Minute ⏰*\n', '┊ ', s, ' *Second ⏱️*'].map(v => v.toString().padStart(2, 0)).join('')
}