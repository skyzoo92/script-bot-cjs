const fs = require('fs')
const fetch = require('node-fetch')
const moment = require('moment-timezone')
const axios = require('axios')
const speed = require('performance-now')
const { catbox } = require("@kelvdra/scraper")

function wktuwib() {
  let h = moment.tz('Asia/Jakarta').format('HH')
  let m = moment.tz('Asia/Jakarta').format('mm')
  let s = moment.tz('Asia/Jakarta').format('ss')
  return `${h} H ${m} M ${s} S`
}

let handler = m => m
handler.all = async function(m) {
    global.name = await m.pushName || this.getName(m.sender)
    global.pp = 'https://files.catbox.moe/a1wkxg.jpg'
    let fotonyu = 'https://files.catbox.moe/pjitvj.jpg'
    try {
        pp = await this.profilePictureUrl(m.sender, 'image')
    } catch (e) {} finally {


                // Function
                global.pickRandom = function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

                global.getBuffer = async function getBuffer(url, options) {
	try {
		options ? options : {}
		var res = await axios({
			method: "get",
			url,
			headers: {
				'DNT': 1,
				'User-Agent': 'GoogleBot',
				'Upgrade-Insecure-Request': 1
			},
			...options,
			responseType: 'arraybuffer'
		})
		return res.data
	} catch (e) {
		console.log(`Error : ${e}`)
	}
}
        const reply = async (msg, options = {}) => {
        const content = typeof msg === 'string' ? msg : JSON.stringify(msg, null, 2);
      return await conn.sendMessage(m.chat, { text: content, ...options }, { quoted: m });
    };
        global.reply2 = reply
        global.emror = 'https://files.catbox.moe/68wa8k.jpg'

        global.doc = pickRandom(["application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/msword", "application/pdf"])
        global.fsizedoc = pickRandom([2000, 3000, 2023000, 2024000])


        // modul
        global.axios = require('axios')
        global.fetch = require('node-fetch')
        global.cheerio = require('cheerio')
        global.fs = require('fs')
        global.hydra = require('@kelvdra/scraper')
        global.crypto = require('crypto')
        

        let timestamp = speed();
        let latensi = speed() - timestamp;
        let ms = await latensi.toFixed(4)
        const _uptime = process.uptime() * 1000

        // Ini untuk command crator/owner
        global.kontak2 = [
            [staff.owner[0], await conn.getName(staff.owner[0] + '0@s.whatsapp.net'), 'Hydra', 'https://whatsapp.com', true],
        ]

		global.fkontak = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: `status@broadcast` } : {}) }, message: { 'contactMessage': { 'displayName': name, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${name},;;;\nFN:${name},\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabell:Ponsel\nEND:VCARD`, 'jpegThumbnail': pp, thumbnail: pp, sendEphemeral: true}}}
		
		global.metaai = {
            key: { 
                 fromMe: false,
                 participant: `0@s.whatsapp.net`, ...(m.chat ? 
            { remoteJid: "status@broadcast" } : {}) 
                       },
            message: {
                conversation: `*Rapthalia - MD • Dibuat Oleh Hydra*`
            }
        }
        
        global.fkon = {
            key: {
                fromMe: false,
                participant: m.sender,
                ...(m.chat ? {
                    remoteJid: 'BROADCAST GROUP'
                } : {})
            },
            message: {
                contactMessage: {
                    displayName: `${name}`,
                    vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;a,;;;\nFN:${name}\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
                }
            }
        }

        // pesan sementara
        global.ephemeral = '86400'

        global.ucapan = ucapan()
        global.time = wktuwib()
        global.date = date()

        global.adReply = {
            contextInfo: {
                mentionedJid: [m.sender], 
                forwardingScore: 1,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    "newsletterJid": "120363298688453806@newsletter",
                    "serverMessageId": -1,
                    "newsletterName": `📍ᴘɪɴɢ: ${ms}ms  || ᴘᴏᴡᴇʀᴇᴅ ʙʏ ʜʏᴅʀᴀ`

                },
            }
        }
        global.fsaluran = { key : {
remoteJid: '0@s.whatsapp.net',
participant : '0@s.whatsapp.net'
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: `${global.staff.idsal}`,
    newsletterName: '',
    caption: "Rapthalia Kawai By Hydra",
}}}
		global.fpayment = {
				"key": {
					"remoteJid": "0@s.whatsapp.net",
					"fromMe": false,
					"id": "BAE595C600522C9C",
					"participant": "0@s.whatsapp.net"
				},
				"message": {
					"requestPaymentMessage": {
						"currencyCodeIso4217": "Elaina Kawai",
						"amount1000": fsizedoc,
						"requestFrom": "0@s.whatsapp.net",
						"noteMessage": {
							"extendedTextMessage": {
								"text": "Project Hydra",
							}
						},
						"expiryTimestamp": fsizedoc,
						"amount": {
							"value": fsizedoc,
							"offset": fsizedoc,
							"currencyCode": info.wm
						}
					}
				}
			}
			
        global.fakeig2 = {
         contextInfo: { externalAdReply: { showAdAttribution: true,
            mediaUrl: global.link.sig,
            mediaType: "VIDEO",
            description: global.link.sig, 
            title: info.wm3,
            body: info.wm,
            thumbnailUrl: pp,
            sourceUrl: link.sig
    }
    } }
        global.fakeig = {
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: staff.namebot,
                    body: ucapan(),
                    thumbnailUrl: pp,
                    sourceUrl: link.sig
                    
                }
            }
        }
    }
}

global.flaaa = [
'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=', 
'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=water-logo&script=water-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextColor=%23000&shadowGlowColor=%23000&backgroundColor=%23000&text=',
'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=crafts-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&text=',
'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=amped-logo&doScale=true&scaleWidth=800&scaleHeight=500&text=',
'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=',
'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&fillColor1Color=%23f2aa4c&fillColor2Color=%23f2aa4c&fillColor3Color=%23f2aa4c&fillColor4Color=%23f2aa4c&fillColor5Color=%23f2aa4c&fillColor6Color=%23f2aa4c&fillColor7Color=%23f2aa4c&fillColor8Color=%23f2aa4c&fillColor9Color=%23f2aa4c&fillColor10Color=%23f2aa4c&fillOutlineColor=%23f2aa4c&fillOutline2Color=%23f2aa4c&backgroundColor=%23101820&text=']

global.fakes = pickRandom([global.fakeig, global.fkontak])
module.exports = handler

function date() {
    let d = new Date(new Date + 3600000)
    let locale = 'id'
    let week = d.toLocaleDateString(locale, {
        weekday: 'long'
    })
    let date = d.toLocaleDateString(locale, {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    })
    let tgl = `${week}, ${date}`
    return tgl
}

function ucapan() {
    const time = moment.tz('Asia/Jakarta').format('HH')
    let res = "Selamat malam "
    if (time >= 4) {
        res = "Selamat pagi "
    }
    if (time > 10) {
        res = "Selamat siang "
    }
    if (time >= 15) {
        res = "Selamat sore "
    }
    if (time >= 18) {
        res = "Selamat malam "
    }
    return res
}

function pickRandom(list) {
    return list[Math.floor(list.length * Math.random())]
}