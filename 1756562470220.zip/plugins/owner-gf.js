const fs = require('fs')
const path = require('path')

let handler = async (m, { conn, isROwner, usedPrefix, command, text }) => {
    if (!text) throw `Format salah!\n\nGunakan:\n${usedPrefix + command} <path_file>\n\nContoh:\n${usedPrefix + command} lib/hydra.js`
    const ROOT_DIR = process.cwd()
    let filePath = path.resolve(ROOT_DIR, text)
    if (!fs.existsSync(filePath)) throw '❌ File tidak ditemukan!'
    if (!filePath.startsWith(ROOT_DIR)) throw '⚠️ Akses ke luar folder tidak diperbolehkan!'

    await conn.sendMessage(m.chat, { 
        document: { url: filePath }, 
        fileName: path.basename(filePath), 
        mimetype: 'application/octet-stream' 
    }, { quoted: m })
}

handler.help = ['getfile'].map(v => v + ' <path_file>')
handler.tags = ['owner']
handler.command = /^(getfile|gf)$/i
handler.rowner = true

module.exports = handler