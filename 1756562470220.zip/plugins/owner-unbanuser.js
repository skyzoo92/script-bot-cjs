let handler = async (m, { conn, isOwner, text }) => {
  if (!isOwner) {
    global.dfail('owner', m, conn)
    throw false
  }

  if (!text) throw 'Masukkan nomor atau tag user yang ingin di-unban\n\nContoh: .unban 6282361160044'

  let who = m.mentionedJid[0] 
    ? m.mentionedJid[0] 
    : m.quoted 
      ? m.quoted.sender 
      : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'

  if (!global.db.data.users[who]) {
    throw 'User tidak ditemukan di database!'
  }

  global.db.data.users[who].banned = false
  m.reply(`✅ ${await conn.getName(who)} sudah di-unban dan bisa menggunakan bot lagi.`)
}

handler.help = ['unban']
handler.tags = ['owner']
handler.command = /^unban$/i
handler.owner = true

module.exports = handler