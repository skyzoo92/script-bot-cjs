const axios = require("axios");
const util = require("util");

let handler = async (m, { text }) => {
    if (!/^https?:\/\//.test(text)) {
        return m.reply('*Masukkan URL-nya!*\n\nContoh:\n.get https://api.vreden.my.id/api/ytmp3?url=https://youtube.com/watch?v=YBnxAP6qst4');
    }
    try {
        const { data, headers } = await axios.get(text);
        const contentType = headers["content-type"];
        if (contentType.startsWith('image/')) {
            await conn.sendMessage(m.chat, {
                image: { url: text },
                caption: `${text}\n\n*Headers Respons:*\n${Object.entries(headers).map(([key, value]) => `*${key}:* ${value}`).join('\n')}`
            }, { quoted: m });
        } else if (contentType.startsWith('video/')) {
            await conn.sendMessage(m.chat, {
                video: { url: text },
                caption: `${text}\n\n*Headers Respons:*\n${Object.entries(headers).map(([key, value]) => `*${key}:* ${value}`).join('\n')}`
            }, { quoted: m });
        } else if (contentType.startsWith('audio/')) {
            await conn.sendMessage(m.chat, {
                audio: { url: text },
                mimetype: 'audio/mpeg'
            }, { quoted: m });
        } else {
            await m.reply(util.format(data));
        }
    } catch (error) {
        await m.reply(`Terjadi kesalahan:\n${util.format(error)}`);
    }
};

handler.help = ['get'].map(v => v + ' <url>');
handler.tags = ['internet'];
handler.command = /^(fetch|get)$/i;
handler.limit = 4;
handler.register = true;

module.exports = handler