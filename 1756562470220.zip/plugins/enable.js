let handler = async (m, {
    command,
    usedPrefix,
    isOwner,
    isROwner,
    isAdmin,
    text,
    args
}) => {
    let isEnable = /true|enable|(turn)?on|1/i.test(command)
    let chat = global.db.data.chats[m.chat]
    let user = global.db.data.users[m.sender]
    let type = (args[0] || '').toLowerCase()
    let isAll = false
    let isUser = false

    const rapthalia = `List opsi untuk *${isEnable ? 'Enable' : 'Disable'}*\nPilih salah satu untuk mengaktifkan atau menonaktifkan fitur:`
   
    const sections = [{
        title: "GROUP FEATURES",
        rows: [
            { title: "Welcome", id: `${usedPrefix}${command} welcome` },
            { title: "Antilink", id: `${usedPrefix}${command} antilink` },
            { title: "Antipoto", id: `${usedPrefix}${command} antipoto` },
            { title: "Antisticker", id: `${usedPrefix}${command} antisticker` },
            { title: "Autosticker", id: `${usedPrefix}${command} autosticker` },
            { title: "Toxic Filter", id: `${usedPrefix}${command} toxic` },
            { title: "AntiBot", id: `${usedPrefix}${command} antibot` },
            { title: "antiPorn", id: `${usedPrefix}${command} antiporn` }
        ]
    }, {
        title: "PERSONAL / OWNER",
        rows: [
            { title: "Autolevelup", id: `${usedPrefix}${command} autolevelup` },
            { title: "Autoread", id: `${usedPrefix}${command} autoread` },
            { title: "Private Only", id: `${usedPrefix}${command} pconly` },
            { title: "Group Only", id: `${usedPrefix}${command} gconly` },
            { title: "Status Only", id: `${usedPrefix}${command} swonly` },
            { title: "Ngetik", id: `${usedPrefix}${command} Ngetik` }
        ]
    }]

    if (!type) {
        return await conn.sendList(m.chat, "Click The Open", sections, m, {
            body: rapthalia,
            footer: "Powered by Hydra",
        })
    }

    switch (type) {
        case 'welcome':
        case 'antilink':
        case 'antisticker':
        case 'antipoto':
        case 'autosticker':
        case 'toxic':
        case 'antibot':
        case 'antiporn':
            if (m.isGroup && !(isAdmin || isOwner)) {
                global.dfail('admin', m, conn)
                throw false
            }
            if (!m.isGroup && !isOwner) {
                global.dfail('group', m, conn)
                throw false
            }
            if (type == 'welcome') chat.welcome = isEnable
            if (type == 'antilink') chat.antiLink = isEnable
            if (type == 'antisticker') chat.antiSticker = isEnable
            if (type == 'antipoto') chat.antiFoto = isEnable
            if (type == 'autosticker') chat.stiker = isEnable
            if (type == 'toxic') chat.antiToxic = !isEnable
            if (type == 'antibot') chat.antiBot = isEnable
            if (type == 'antiporn') chat.antiPorn = isEnable
            break
        case 'autolevelup':
            isUser = true
            user.autolevelup = isEnable
            break
        case 'autoread':
        case 'pconly':
        case 'gconly':
        case 'swonly':
        case 'ngetik':
            isAll = true
            if (!isROwner) {
                global.dfail('rowner', m, conn)
                throw false
            }
            global.opts[type] = isEnable
            break
        default:
            return await conn.sendList(m.chat, "Click The Open", sections, m, {
                body: rapthalia,
                footer: "Powered by Hydra",
                url: logo.rapthalia
            })
    }

    m.reply(`✅ *${type}* berhasil di *${isEnable ? 'aktifkan' : 'nonaktifkan'}* ${isAll ? 'untuk bot ini' : isUser ? '' : 'untuk chat ini'}`)
}

handler.help = ['en', 'dis'].map(v => v + 'able *[options]*')
handler.tags = ['owner']
handler.command = /^((en|dis)able|(tru|fals)e|(turn)?o(n|ff)|[01])$/i

module.exports = handler