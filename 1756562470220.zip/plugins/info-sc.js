let handler = async (m, { conn, usedPrefix }) => {
return new Button()
.setBody( `*SELL SCRIPT RAPTHALIA MD ${info.version}*
🏷️ Price : *Rp. 30.000 / $5.67*

*Special Features :*
🎉 • Giveaway Group
🎋 • Antilink & Welcome
🎐 • Open / Close Group Time
🍰 • Pinterest Slide
🎣 • Full Button 
🌼 • Sambutan Owner
🤖 • AI & AI Image
📛 • Anti Bot
📊 • Leveling & Roles
🏦 • Bank Gopay / Dana / Ovo

*Command :*
Bisa cek sendiri di nomor bot +${staff.nomorbot}

*Benefits :*
• Free Update
• No Enc 100%

*Requirement :*
• NodeJS v18
• FFMPEG
• IMAGEMAGICK
• Ram Min. 5GB

Minat ? *Pencet Di Bawah*`)
.setFooter('ʀᴀᴘᴛʜᴀʟɪᴀ ᴍᴅ ᴍᴀᴅᴇ ʙʏ ʜʏᴅʀᴀ')
.setImage("https://files.catbox.moe/0htwx9.jpg")
.addUrl('Costumer Support','https://wa.me/6285173328399','https://wa.me/6285173328399')
.run(m.chat, conn, m)
}
handler.help = ['script']
handler.tags = ['info']
handler.command = /^(sc|sourcecode|script)$/i
handler.register = false

module.exports = handler