const axios = require('axios');
const cheerio = require('cheerio');

async function scrapeTikTok(tiktokUrl) {
  const payload = new URLSearchParams();
  payload.append('q', tiktokUrl);
  payload.append('lang', 'en');
  payload.append('cftoken', '');

  const res = await axios.post(
    'https://savetik.co/api/ajaxSearch',
    payload.toString(),
    {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
      },
    }
  );

  const data = res.data.data;
  const $ = cheerio.load(data);

  const title = $('.content h3').text().trim();
  const thumbnail = $('.thumbnail img').attr('src') || null;

  const videoDownloads = [];
  $('.dl-action a').each((i, el) => {
    const type = $(el).text().trim().toLowerCase();
    const url = $(el).attr('href');
    if (url && url.startsWith('http')) {
      videoDownloads.push({ type, url });
    }
  });

  const photos = [];
  $('.photo-list .download-box li').each((i, el) => {
    const img = $(el).find('img').attr('src');
    const url = $(el).find('a').attr('href');
    if (img && url) {
      photos.push({ preview: img, url });
    }
  });

  return {
    title,
    thumbnail,
    video: videoDownloads,
    photos
  };
}

const handler = async (m, { conn, text }) => {
  if (!text) return m.reply('Mana link TikTok-nya?');

  await m.reply('Tunggu sebentar, lagi ngunduh...');
  let result;
  try {
    result = await scrapeTikTok(text);
  } catch (e) {
    console.error(e);
    return m.react('❌');
  }

  if (!result) return m.react('❌');

  // Pilih video HD dulu, fallback ke MP4 biasa kalau tidak ada
  const videoLinkHD = result.video.find(v => v.type.includes('hd'))?.url;
  const videoLinkNormal = result.video.find(v => v.type.includes('mp4') && !v.type.includes('hd'))?.url;
  const videoLink = videoLinkHD || videoLinkNormal;

  const audioLink = result.video.find(v => v.type.includes('mp3'))?.url;
  const photoLinks = result.photos;

  if (videoLink) {
    await conn.sendMessage(m.chat, {
      video: { url: videoLink },
      caption: result.title
    }, { quoted: m });
  } else if (photoLinks.length) {
    const slideImages = photoLinks.map(photo => ({
      image: { url: photo.url },
      caption: result.title
    }));

    if (slideImages.length > 1) {
      await conn.sendAlbumMessage(m.chat, slideImages, { quoted: m, delay: 2000 });
    } else if (slideImages.length === 1) {
      await conn.sendMessage(m.chat, slideImages[0], { quoted: m });
    }
  } else {
    return m.react('❌');
  }

  if (audioLink) {
    await conn.sendMessage(m.chat, {
      audio: { url: audioLink },
      mimetype: 'audio/mp4'
    }, { quoted: m });
  }
};

handler.help = ['tiktokhd2'];
handler.tags = ['premium'];
handler.command = ['tthd2', 'tiktokhd2', 'ttdlhd2', 'tiktokdlhd2'];
handler.premium = true
module.exports = handler;