const fs = require('fs')

let handler = async (m, { conn }) => {
 conn.sendMessage(m.chat, {
      video: { url: "https://files.catbox.moe/sbexdw.mp4"},
      gifPlayback: true,
       caption :`RAPTHALIA - Multidevice  adalah bot WhatsApp yang cerdas dan sangat berguna untuk membantu Anda dalam menjawab pertanyaan dan memberikan solusi yang tepat dalam waktu yang singkat. Dikembangkan oleh Hydra , bot ini menggunakan sumber asli base RAPTHALIA AI yang terus diperbarui oleh Hydra  untuk memberikan pengalaman berinteraksi yang lebih mudah dan menyenangkan.\nDengan kemampuannya yang luas dalam menjawab pertanyaan dan memberikan solusi, Bot Rapthalia - Multidevice  dapat membantu Anda dalam berbagai hal seperti, mencari informasi tentang produk atau layanan, mengatur jadwal, dan banyak lagi. Bot Rapthalia - Multidevice  juga dapat memberikan jawaban yang akurat dan cepat sehingga Anda tidak perlu lagi menunggu lama untuk mendapatkan jawaban yang Anda butuhkan.\nSebagai produk yang dikembangkan dan diperbarui oleh Hydra , Bot Rapthalia - Multidevice  selalu menerima pembaruan fitur-fitur terbaru untuk memberikan layanan yang semakin baik dan canggih. Dengan Bot Rapthalia - Multidevice , Anda tidak perlu khawatir tentang kualitas layanan yang diberikan karena bot ini selalu siap memberikan solusi yang terbaik bagi pengguna WhatsApp. Jadi, tunggu apa lagi? Gunakan Bot Rapthalia - Multidevice  sekarang dan nikmati kemudahan serta kenyamanan dalam berinteraksi dengan bot cerdas ini di WhatsApp!\n\nRapthalia - Multidevice  is a smart WhatsApp bot that is very useful for helping you answer questions and provide accurate solutions in a short amount of time. Developed by Hydra , this bot uses the original source of Botcahx that is constantly updated by Hydra to provide an easier and more enjoyable interactive experience.With its broad ability to answer questions and provide solutions, Bot Rapthalia - Multidevice  can assist you in various things such as searching for information about products or services, scheduling appointments, and much more. Bot Rapthalia - Multidevice  can also provide accurate and quick answers so you no longer have to wait long to get the answers you need.\nAs a product developed and updated by Hydra , Bot Rapthalia - Multidevice  always receives the latest feature updates to provide better and more advanced services.With Bot Rapthalia - Multidevice , you dont have to worry about the\nquality of the service provided because this bot is always ready to provide the best solutions for WhatsApp users. So, what are you waiting for? Use Bot yukk now and enjoy the ease and convenience of interacting with this smart bot on WhatsApp!`,
       footer: "Rapthalia AI",
      contextInfo: {
      externalAdReply: {
      title: `© About Rapthalia - Multidevice`,
      body: global.staff.nameown,
      thumbnailUrl: logo.rapthalia,
      sourceUrl: link.sgc,
      mediaType: 1,
      renderLargerThumbnail: true
      }}})
}
handler.command = /^(about)$/i;
handler.help = ["about"]
handler.tags = ["info"]

module.exports = handler