/**
 * By: Hydra
 * 𝘵𝘦𝘭𝘦: https://t.me/draa82
 * 𝘪𝘯𝘧𝘰: https://s.id/Genzo82
 * 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VadrgqYKbYMHyMERXt0e
 * 🚨Di Larang Menghapus Wm Ini🚨
 * #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁
 */

const fs = require('fs')
const path = require('path')

let handler = async (m, { conn, args, usedPrefix, command }) => {
    let nomor = args[0]
    if (!nomor) return m.reply(`Nomor tujuan tidak ditemukan!\n\nContoh:\n${usedPrefix + command} 6285173328399 menu.js`)

    let target = nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    const isValid = await conn.onWhatsApp(target)
    if (!isValid.length) return m.reply('❌ Nomor tidak terdaftar di WhatsApp!')

    // Handle berdasarkan command
    if (command === 'sendplug') {
        let fileName = args[1]
        if (!fileName) return m.reply(`Nama file plugin tidak ditemukan!\n\nContoh:\n${usedPrefix + command} ${nomor} menu.js`)

        let filePath = path.resolve('./plugins', fileName)
        if (!fs.existsSync(filePath)) return m.reply('❌ File tidak ditemukan di folder plugins!')

        await conn.sendMessage(target, {
            document: fs.readFileSync(filePath),
            fileName: fileName,
            mimetype: 'application/octet-stream',
            caption: 'Nih bang dari plugins'
        })

        conn.reply(m.chat, `✅ File *${fileName}* berhasil dikirim ke @${target.split('@')[0]}`, m, {
            contextInfo: { mentionedJid: [target] }
        })

    } else if (command === 'sendfile') {
        let filePathInput = args.slice(1).join(' ')
        if (!filePathInput) return m.reply(`Path file tidak ditemukan!\n\nContoh:\n${usedPrefix + command} ${nomor} lib/hydra.js`)

        let fullPath = path.resolve(process.cwd(), filePathInput)
        if (!fs.existsSync(fullPath)) return m.reply('❌ File tidak ditemukan!')
        if (!fullPath.startsWith(process.cwd())) return m.reply('⚠️ Akses ke luar folder tidak diperbolehkan!')

        await conn.sendMessage(target, {
            document: fs.readFileSync(fullPath),
            fileName: path.basename(fullPath),
            mimetype: 'application/octet-stream',
            caption: 'Nih bang dari path umum'
        })

        conn.reply(m.chat, `✅ File *${path.basename(fullPath)}* berhasil dikirim ke @${target.split('@')[0]}`, m, {
            contextInfo: { mentionedJid: [target] }
        })
    }
}

handler.help = ['sendplug <nomor> <nama_file>', 'sendfile <nomor> <path_file>']
handler.tags = ['owner']
handler.command = /^(sendplug|sendfile)$/i
handler.rowner = true

module.exports = handler