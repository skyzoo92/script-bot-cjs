const rewards = {
    exp: 5000,
    money: 4999,
    potion: 10,
    mythic: 3,
    legendary: 1
}

const cooldown = 2592000000 // 30 hari (ms)

let handler = async (m, { conn }) => {
    let user = global.db.data.users[m.sender]
    let now = new Date() * 1

    if (now - user.lastmonthly < cooldown) {
        let remaining = user.lastmonthly + cooldown - now
        throw `You have already claimed this monthly claim, wait for *${msToTime(remaining)}*`
    }

    let text = ''
    for (let reward of Object.keys(rewards)) {
        if (!(reward in user)) continue
        user[reward] += rewards[reward]
        text += `*+${rewards[reward]}* ${global.rpg.emoticon(reward)}${reward}\n`
    }

    conn.reply(m.chat, `MONTHLY\n${text.trim()}`, m)
    user.lastmonthly = now
}

function msToTime(ms) {
    let seconds = Math.floor((ms / 1000) % 60)
    let minutes = Math.floor((ms / (1000 * 60)) % 60)
    let hours = Math.floor((ms / (1000 * 60 * 60)) % 24)
    let days = Math.floor(ms / (1000 * 60 * 60 * 24))
    return `${days}d ${hours}h ${minutes}m ${seconds}s`
}

handler.help = ['monthly']
handler.tags = ['rpg']
handler.command = /^(monthly)$/i

handler.cooldown = cooldown

module.exports = handler