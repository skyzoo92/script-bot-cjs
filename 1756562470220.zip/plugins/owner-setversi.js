const fs = require('fs');

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    m.reply(`*Example:* ${usedPrefix + command} 1.0.1`);
    return;
  }

  const configFile = './settings.js';
  let data = fs.readFileSync(configFile, 'utf8');

  let newValue = `version: '${text}'`;

  // Ganti nilai version di dalam global.info
  let updated = data.replace(/version:\s*'[^']*'/, newValue);

  fs.writeFileSync(configFile, updated, 'utf8');

  m.reply('✓ Berhasil mengubah versi bot');
};

handler.help = ['setversi <versi>'];
handler.tags = ['owner'];
handler.owner = true;
handler.command = /^(setversi(on)?)$/i;

module.exports = handler