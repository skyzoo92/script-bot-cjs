const linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i;

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*• Example :* ${usedPrefix + command} *[link,duration]*`;
  let [Target, duration] = text.split(",");
  if (!Target) return;
  if (!isUrl(Target)) throw "*[!] Input Link Group*";
  let [_, code] = Target.match(linkRegex) || [];
  if (!code) throw "*[!] Invalid Group Link*";
  let id = await conn.groupAcceptInvite(code);
  if (!duration || isNaN(duration)) throw "*[!] Invalid duration, please input a number*";
  let milidetikDalamHari = 24 * 60 * 60 * 1000;
  let hasil = duration * milidetikDalamHari;
  let { key } = await conn.sendMessage(
    m.chat,
    { text: "*[ VERIFYING DATA... ]*" },
    { quoted: m }
  );
  const user = db.data.chats[id] || {};
  user.sewa = true;
  user.expired = Date.now() + hasil;
  db.data.chats[id] = user;
  await conn.sendMessage(
    m.chat,
    {
      text: `*[ ✅ VERIFICATION SUCCESS ]*
*• Sewabot:* ${user.sewa ? "✅" : "❎"}
*• Expired:* ${duration} *Day* *[${toDate(user.expired)}]*`,
      edit: key,
    },
    { quoted: m }
  );
  await conn.sendMessage(
    id,
    {
      text: `Hi Semuanya, saya adalah *Elaina Bot*. Saya akan menjadi asisten grup ini selama ${duration} hari, silahkan nikmati fitur yang telah kami sediakan. Jangan salahgunakan fitur bot, tetap baca *.rules* kami sebelum menggunakan bot ini.
      
Ketik *.menu* untuk melihat fitur bot`,
    },
    { quoted: null }
  );
};
function isUrl(url) {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
}
function toDate(timestamp) {
  let date = new Date(timestamp);
  return date.toLocaleDateString("id-ID", { year: "numeric", month: "long", day: "numeric" });
}
handler.help = ["sewa"].map((a) => a + " *[link,duration]*");
handler.tags = ["owner"];
handler.command = ["sewa"];
handler.owner = true;

module.exports = handler