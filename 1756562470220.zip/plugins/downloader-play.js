const hydraa = require('@kelvdra/scraper');
const fs = require('fs');
const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = require('@kelvdra/bails')
const { format } = require('util');

let handler = async (m, {
    conn,
    usedPrefix,
    command,
    text
}) => {
    if (!text) {
        return m.reply(`[❗] Masukan Salah\n\nContoh: ${usedPrefix + command} Dj The Spectre`);
    }
    m.react("⏱")
    const id = m.sender;
    const search = await hydraa.search(text);
    if (!search || !search.results.length) {
        throw 'Video tidak ditemukan. Coba judul lain.';
    }
    const vid = search.results[0];
    const { title, thumbnail, timestamp, views, ago, url } = vid;
    if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp');
    if (!conn.data) conn.data = {};
    conn.data[id] = {
        user: id,
        title,
        times: timestamp,
        views,
        ago,
        url,
        thumbnail
    };
    let { hydra } = global.info

    const captvid = `
*🎬 Hasil Ditemukan*

📌 *Judul:* ${title}
⏱️ *Durasi:* ${timestamp}
👀 *Views:* ${views}
📅 *Published:* ${ago}
🔗 *Link:* ${url}

━━━━━━━━━━━━━━━
*⚡ Pilih Opsi:*
🎵 Audio
🎥 Video
━━━━━━━━━━━━━━━

📛 ${info.date}
_${info.titlebot}_
`
    const buttons = [
        { buttonId: `.ytmp3 ${url}`, buttonText: { displayText: 'AUDIO' }, type: 1 },
        { buttonId: `.ytmp4 ${url}`, buttonText: { displayText: 'VIDEO' }, type: 1 }
    ];

    const buttonsMessage = {
        image: { url: thumbnail },
        caption: `${captvid}`,
        footer: "Rapthalia Kawai By Hydra",
        buttons,
        headerType: 4,
        contextInfo: {
            externalAdReply: {
                title: '',
                thumbnailUrl: thumbnail,
                sourceUrl: url,
                mediaType: 1,
                renderLargerThumbnail: false,
                mentionedJid: [m.sender]
            }
        }
    };

    await conn.sendMessage(m.chat, buttonsMessage, { quoted: m });

    setTimeout(() => {
        conn.sendMessage(m.chat, { react: { text: '🎶', key: m.key } });
        delete conn.data[id];
    }, 30000);
};

handler.help = ["play"].map(v => v + " <query>");
handler.tags = ["downloader"];
handler.command = /^(play)$/i;
handler.limit = 4;

module.exports = handler