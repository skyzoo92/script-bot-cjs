/**
 * By: Hydra
 * 𝘵𝘦𝘭𝘦: https://t.me/draa82
 * 𝘪𝘯𝘧𝘰: https://s.id/Genzo82
 * 𝘔𝘢𝘬𝘦𝘳: https://whatsapp.com/channel/0029VadrgqYKbYMHyMERXt0e
 * 🚨Di Larang Menghapus Wm Ini🚨
 * #𝗛𝗮𝗿𝗴𝗮𝗶𝗹𝗮𝗵 𝗣𝗲𝗺𝗯𝘂𝗮𝘁
 jika script mu gada batas comand, hapus saja itu handler.comand
**/

const ytdl = require("@kelvdra/scraper"); 

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    let [Url, quality] = text.split(',');

    if (!Url) {
        return conn.reply(m.chat, `Gunakan format: ${usedPrefix}${command} <url> [resolusi]`, m);
    }
       
       let Quality = quality || '128';
       let data = await ytdl.ytmp3(Url, Quality);
			try {	
			const caption = `*${data.metadata.title}*

*⌬ Ext* : Download
*⌬ ID* : ${data.metadata.videoId}
*⌬ Durasi* : ${data.metadata.timestamp}
*⌬ Upload* : ${data.metadata.ago}
*⌬ Views* : ${data.metadata.views}
*⌬ Quality* : ${data.download.quality}
*⌬ Channel* : ${data.metadata.author.name}

_*Nihh Omm...*_`;
				conn.sendMessage(m.chat, {
					document: {
						url: data.download.url
					},
					mimetype: 'audio/mpeg',
					fileName: data.download.filename,
					caption: "",
					contextInfo: {
						mentionedJid: [m.sender],
						externalAdReply: {
							title: `YouTube ${data.download.quality} 🍟`,
							previewType: "PHOTO",
							thumbnailUrl: `${data.metadata.thumbnail}`,
							sourceUrl: Url
						}
					}
				}, {
					quoted: m
				})
conn.sendMessage(m.chat, { react: { text: '', key: m.key } });
			} catch (error) {
				await m.reply("error");
			}
};

handler.help = ['ytadoc'].map(v => v + ' <query>');
handler.tags = ['downloader'];
handler.command = /^(ytaudiodoc|ytmp3doc|ytadoc)$/i;
handler.limit = 3
handler.register = true
module.exports = handler