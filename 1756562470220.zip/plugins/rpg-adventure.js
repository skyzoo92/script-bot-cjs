const baileys = require("@kelvdra/bails")
const {MessageType} = baileys;

let handler = async (m, { conn, usedPrefix }) => {
    try {
        let user = global.db.data.users[m.sender];
        if (!user.sword) return conn.reply(m.chat, `⚔️ Kamu belum punya sword, ketik *${usedPrefix}craft sword* dulu untuk mulai adventure!`, m);
        if (!user.armor) return conn.reply(m.chat, `🛡️ Kamu belum punya armor, ketik *${usedPrefix}craft armor* dulu untuk mulai adventure!`, m);

        let __timers = new Date() - (user.lastadventure || 0);
        let _timers = 600000 - __timers;
        let timers = clockString(_timers);

        if (user.health <= 79) return conn.reply(m.chat, `🩸 Minimal 80 health untuk adventure.\nGunakan potion dengan ketik *${usedPrefix}shop buy potion <jumlah>* lalu *${usedPrefix}use potion <jumlah>*`, m);

        if (__timers < 600000) return conn.reply(m.chat, `💧 Kamu kelelahan, silakan tunggu *${timers}* lagi sebelum adventure lagi.`, m);

        // Enemy list
        let monsters = [
            { name: 'Goblin', health: 20, attack: 5 },
            { name: 'Troll', health: 50, attack: 10 },
            { name: 'Dragon', health: 100, attack: 20 },
            { name: 'Zombie', health: 30, attack: 7 },
            { name: 'Vampire', health: 40, attack: 15 },
            { name: 'Werewolf', health: 70, attack: 17 },
            { name: 'Skeleton', health: 25, attack: 8 },
            { name: 'Orc', health: 60, attack: 12 },
            { name: 'Witch', health: 45, attack: 14 },
            { name: 'Golem', health: 80, attack: 18 },
            { name: 'Demon', health: 120, attack: 25 },
            { name: 'Phoenix', health: 150, attack: 30 },
            { name: 'Hydra', health: 200, attack: 35 },
            { name: 'Kraken', health: 250, attack: 40 },
            { name: 'Minotaur', health: 300, attack: 45 },
            { name: 'Basilisk', health: 350, attack: 50 },
            { name: 'Griffin', health: 400, attack: 55 },
            { name: 'Cyclops', health: 450, attack: 60 },
            { name: 'Chimera', health: 500, attack: 65 },
            { name: 'Leviathan', health: 550, attack: 70 },
        ];
        let bosses = [
            { name: 'Ancient Dragon', health: 1000, attack: 100 },
            { name: 'Dark Lord', health: 1200, attack: 120 },
            { name: 'Titan', health: 1500, attack: 150 },
            { name: 'Elder God', health: 2000, attack: 200 },
        ];

        let isBoss = Math.random() < 0.1; // 10% chance boss
        let enemy = isBoss ? pickRandom(bosses) : pickRandom(monsters);
        let enemyHealth = enemy.health;
        let enemyAttack = enemy.attack;

        let userAttack = 10; // Bisa diatur nanti berdasarkan equipment
        while (user.health > 0 && enemyHealth > 0) {
            enemyHealth -= userAttack;
            if (enemyHealth > 0) user.health -= enemyAttack;
        }

        if (user.health <= 0) {
            conn.reply(m.chat, `😵 Kamu kalah melawan ${enemy.name}.\nSembuhkan diri dulu sebelum lanjut petualangan.`, m);
            return;
        }

        // Reward
        let healthLoss = Math.floor(Math.random() * 101);
        let expGain = Math.floor(Math.random() * 10000);
        let moneyGain = Math.floor(Math.random() * 100000);
        let potionGain = randomPick(['1', '2', '3']);
        let sampahGain = randomPick([...Array(50).keys()].map(i => i + 1));
        let diamondGain = randomPick(['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']);
        let commonCrate = randomPick(['1', '2', '3']);
        let uncommonCrate = randomPick(['1', '2']);
        let mythicCrate = pickRandom(['1', '1', '2', '1', '3']);
        let legendaryCrate = pickRandom(['1', '1', '2', '1', '3']);
        let locations = [
            '🏯 Jepang', '🇰🇷 Korea', '🏝️ Bali', '🇺🇸 Amerika', '🇮🇶 Iraq', '🇸🇦 Arab', '🇵🇰 Pakistan',
            '🇩🇪 German', '🇫🇮 Finlandia', '💤 Dunia Mimpi', '🌍 Ujung Dunia', '🔴 Mars', '🇿🇼 Zimbabwe',
            '🌕 Bulan', '🔵 Pluto', '☀️ Matahari', '💖 Hatinya Dia', '🌲 Hutan Amazon', '🏜️ Gurun Sahara',
            '🏔️ Himalaya', '🌊 Atlantik', '🏰 Kastil Terbengkalai', '🌌 Galaksi Andromeda', '🏞️ Grand Canyon',
            '🏜️ Death Valley', '🏕️ Yosemite', '🏖️ Maldives', '🏙️ New York', '🇮🇳 India', '🇧🇷 Brazil',
            '🇿🇦 Afrika Selatan', '🇦🇺 Australia', '🇨🇦 Kanada', '🇷🇺 Rusia', '🇲🇽 Meksiko', '🇳🇿 Selandia Baru',
            '🏞️ Patagonia', '🇫🇷 Prancis', '🇪🇸 Spanyol', '🇮🇹 Italia', '🇬🇧 Inggris', '🇨🇭 Swiss'
        ];
        let location = pickRandom(locations);

        let rewardText = `
🩸 Nyawa mu berkurang -${healthLoss} setelah bertualang ke ${location} melawan ${enemy.name}.
🎁 Kamu mendapatkan:
✨ Exp: *${expGain}*
💰 Uang: *${moneyGain}*
🎫 Tiketcoin: *1*
🗑️ Sampah: *${sampahGain}*${potionGain ? `\n🧪 Potion: *${potionGain}*` : ''}${diamondGain ? `\n💎 Diamond: *${diamondGain}*` : ''}${commonCrate ? `\n📦 Common Crate: *${commonCrate}*` : ''}${uncommonCrate ? `\n🎁 Uncommon Crate: *${uncommonCrate}*` : ''}
`.trim();

        await conn.reply(m.chat, rewardText, m, {
            contextInfo: {
                externalAdReply: {
                    mediaType: 1,
                    title: 'Rapthalia MD',
                    thumbnailUrl: 'https://telegra.ph/file/221ec27b2997f203569eb.jpg',
                    renderLargerThumbnail: true,
                    sourceUrl: ''
                }
            }
        });

        await conn.reply(m.chat, `🎊 *Selamat!* Kamu mendapatkan rare item:\n${mythicCrate}x Mythic Crate dan ${legendaryCrate}x Legendary Crate!`, m);

        user.health -= healthLoss;
        user.exp += expGain;
        user.money += moneyGain;
        user.tiketcoin += 1;
        user.potion += Number(potionGain);
        user.sampah += Number(sampahGain);
        user.diamond += Number(diamondGain);
        user.common += Number(commonCrate);
        user.uncommon += Number(uncommonCrate);
        user.mythic += Number(mythicCrate);
        user.legendary += Number(legendaryCrate);
        user.lastadventure = Date.now();

        // Equipment durability
        user.sworddurability -= 1;
        user.armordurability -= 1;

        if (user.sworddurability <= 0) {
            user.sword = false;
            conn.reply(m.chat, '⚔️ Sword kamu telah rusak, craft lagi untuk lanjut adventure.', m);
        }
        if (user.armordurability <= 0) {
            user.armor = false;
            conn.reply(m.chat, '🛡️ Armor kamu telah rusak, craft lagi untuk lanjut adventure.', m);
        }

    } catch (e) {
        console.error(e);
        conn.reply(m.chat, '❗ Terjadi error saat adventure. Coba lagi nanti.', m);
    }
};

handler.help = ['adventure'];
handler.tags = ['rpg'];
handler.command = /^adventure$/i;

module.exports = handler;

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
}

function randomPick(array) {
    return array[Math.floor(Math.random() * array.length)];
}

function clockString(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor((ms % 3600000) / 60000);
    let s = Math.floor((ms % 60000) / 1000);
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':');
}