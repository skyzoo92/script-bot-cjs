const baileys = require("@kelvdra/bails")
const {proto,
    generateWAMessageFromContent,
    prepareWAMessageMedia} = baileys

let handler = async (m, { conn, usedPrefix: _p, __dirname, args, command}) => {

await conn.relayMessage(m.chat, { reactionMessage: { key: m.key, text: '✅'  }}, { messageId: m.key.id }) 

 const text = `\`WhatsApp Bot Multi Device\`\n`
    const caption = `\n👋🏻 Hai kak @${m.sender.split("@")[0]}, \nAku Rapthalia Bot WhatsApp Pintar yang dapat membantu anda untuk mencari Informasi, bermain Game, RPG dan di lengkapi dengan Fitur AI (Artificial Intelligence).\n`;

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
              "messageContextInfo": {
                "deviceListMetadata": {},
                "deviceListMetadataVersion": 2
              },
      interactiveMessage: proto.Message.InteractiveMessage.create({
      contextInfo: {
         mentionedJid: [m.sender], 
         isForwarded: true, 
         forwardedNewsletterMessageInfo: {
   newsletterJid: '120363298688453806@newsletter',
   newsletterName: 'Powered By Hydra', 
   serverMessageId: -1
  },
 businessMessageForwardInfo: { businessOwnerJid: conn.decodeJid(conn.user.id) },
 forwardingScore: 256,
            externalAdReply: {  
                title: 'DCODEKEMII', 
                thumbnailUrl: 'https://telegra.ph/file/a6f3ef42e42efcf542950.jpg', 
                sourceUrl: 'https://youtube.com/',
                mediaType: 2,
                renderLargerThumbnail: false
            }
          }, 
        body: proto.Message.InteractiveMessage.Body.create({
          text: caption.trim()
        }),
        footer: proto.Message.InteractiveMessage.Footer.create({
          text: `Klik Url`,
        }),
        header: proto.Message.InteractiveMessage.Header.create({
          hasMediaAttachment: false
        }),
        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.create({
          cards: [
            {
              body: proto.Message.InteractiveMessage.Body.create({
                text: `> *20 Days : 10.000*\n> *30 Days : 15.000*\n> *3 bulan : 30.000*\n\n\`</> Benefit Prem </>\`\n\n> Get Unlimited Limit\n> Get Acces All Fitur Premium`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                title: `\`</> Premium Bot </>\`\n`,
                hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/avxd5o.jpg' } }, { upload: conn.waUploadToServer }))
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                  {
            "name": "cta_url",
            "buttonParamsJson": `{"display_text":"Order Here","url":"https://wa.me/6285173328399","merchant_url":"https://wa.me/625173328399"}`
          }
                  ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.create({
                text: `> *7 Days + 5 Days Premium : 5.000*\n> *30 Days + 15 Days Premium : 20.000*\n> *2 Bulan + 45 Day Premium : 35.000*\n\n\`</> Benefit Sewa </>\`\n\n> Auto Welcome\n> Auto Kick\n`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                title: `\`</> Sewa Bot </>\`\n`,
                hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/avxd5o.jpg' } }, { upload: conn.waUploadToServer }))
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                  {
                    "name": "cta_url",
                    "buttonParamsJson": `{"display_text":"Order Here!","url":"https://wa.me/6285173328399","merchant_url":"https://wa.me/6285173328399"}`
                  }
                  ]
              })
            }
          ]
        })
      })
    }
  }
}, { userJid: m.chat, quoted: m })
conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })
}
handler.help = ["shopbot"]
handler.tags = ["info"]
handler.command = ["shopbot", "sewabot", "premium"]

module.exports = handler