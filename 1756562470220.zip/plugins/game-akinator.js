const {Aki} = require('aki-api')
const fs = require('fs')

let handler = async (m, { conn, usedPrefix, command, args, isPrems }) => {
    conn.akinator = conn.akinator || {}

    if (command == 'akinator') {
        switch (args[0]) {
            case 'end':
                if (!(m.sender in conn.akinator)) return m.reply('Anda tidak sedang dalam sesi Akinator')
                delete conn.akinator[m.sender]
                m.reply('Berhasil keluar dari sesi Akinator.')
                break

            case 'start':
                if (m.sender in conn.akinator) return conn.reply(m.chat, 'Anda masih berada dalam sesi Akinator', m)
                conn.akinator[m.sender] = new Aki({ region: 'id' })
                await conn.akinator[m.sender].start()
                let { question } = conn.akinator[m.sender]
                let txt = `🎮 *Akinator* 🎮\n\n@${m.sender.split('@')[0]}\n${question}\n\n`
                txt += '🎮 _*Silahkan Jawab Dengan Cara:*_\n'
                txt += `_*Ya* - ${usedPrefix}answer 0_\n`
                txt += `_*Tidak* - ${usedPrefix}answer 1_\n`
                txt += `_*Saya Tidak Tahu* - ${usedPrefix}answer 2_\n`
                txt += `_*Mungkin* - ${usedPrefix}answer 3_\n`
                txt += `_*Mungkin Tidak* - ${usedPrefix}answer 4_\n\n`
                txt += `*${usedPrefix + command} end* untuk keluar dari sesi Akinator`
                conn.akinator[m.sender].chat = await conn.reply(m.chat, txt, m, { mentions: [m.sender] })
                conn.akinator[m.sender].waktu = setTimeout(() => {
                    conn.reply(m.chat, `Waktu Memilih Akinator Habis`, conn.akinator[m.sender].chat)
                    delete conn.akinator[m.sender]
                }, 60000)
                break

            default:
                let cap = 'Akinator adalah permainan yang menebak pikiranmu lewat serangkaian pertanyaan.\n\n'
                cap += '🎮 _*Cara Bermain:*_\n'
                cap += `${usedPrefix + command} start ~ Memulai permainan\n`
                cap += `${usedPrefix + command} end ~ Mengakhiri permainan\n`
                cap += `${usedPrefix}answer ~ Menjawab pertanyaan`
                return conn.sendMessage(m.chat, {
                    text: `${cap}\n\n${m.sender in conn.akinator ? '*Kamu Masih Berada Dalam Sesi Akinator*' : ''}`,
                    mentions: [m.sender],
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            forwardingScore: 2023,
                            title: `Akinator`,
                            thumbnailUrl: "https://files.catbox.moe/zips1r.jpg",
                            sourceUrl: "",
                            mediaType: 1,
                            renderLargerThumbnail: true,
                            mentionedJid: [m.sender]
                        }
                    }
                }, { quoted: m })
        }
    }

    if (command == 'answer') {
        if (!(m.sender in conn.akinator)) return m.reply('Kamu belum ada di sesi Akinator!')
        if (!args[0]) return m.reply('Masukkan jawaban kamu!')
        if (!/^[0-4]$/.test(args[0])) return m.reply('Angka jawaban harus 0-4!')

        clearTimeout(conn.akinator[m.sender].waktu)
        await conn.akinator[m.sender].step(args[0])
        let { question, currentStep, progress } = conn.akinator[m.sender]

        if (progress >= 70 || currentStep >= 78) {
            await conn.akinator[m.sender].win()
            let { answers } = conn.akinator[m.sender]
            let cap = `🎮 *Akinator Menjawab*\n\n`
            cap += `Dia adalah *${answers[0].name}* dari *${answers[0].description}*`
            conn.sendFile(m.chat, answers[0].absolute_picture_path, '', cap, m)
            delete conn.akinator[m.sender]
        } else {
            let txt = `🎮 *Akinator* 🎮\n\n@${m.sender.split('@')[0]}\n`
            txt += `_Step ${currentStep} ( ${progress.toFixed(2)}% )_\n\n${question}\n\n`
            txt += '🎮 _*Silahkan Jawab Dengan Cara:*_\n'
            txt += `_*Ya* - ${usedPrefix}answer 0_\n`
            txt += `_*Tidak* - ${usedPrefix}answer 1_\n`
            txt += `_*Saya Tidak Tahu* - ${usedPrefix}answer 2_\n`
            txt += `_*Mungkin* - ${usedPrefix}answer 3_\n`
            txt += `_*Mungkin Tidak* - ${usedPrefix}answer 4_`
            conn.akinator[m.sender].chat = await conn.reply(m.chat, txt, m, { mentions: [m.sender] })
            conn.akinator[m.sender].waktu = setTimeout(() => {
                conn.reply(m.chat, `Waktu Memilih Akinator Habis`, conn.akinator[m.sender].chat)
                delete conn.akinator[m.sender]
            }, 60000)
        }
    }
}

handler.help = ['akinator']
handler.tags = ['game']
handler.command = /^((akinator|answer))$/i
handler.limit = false
handler.game = true
handler.group = true
module.exports = handler