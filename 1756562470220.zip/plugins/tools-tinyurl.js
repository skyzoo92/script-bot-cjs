const axios = require('axios');

let handler = async (m, { text, conn, args }) => {
  if (!text) throw '• *Example :* .tinyurl https://instagram.com';

  try {
    const shortUrl = await shortlink(text);
    if (shortUrl) {
      conn.reply(m.chat, shortUrl, m);
    } else {
      conn.reply(m.chat, 'Invalid URL', m);
    }
  } catch (error) {
    console.error(error);
    conn.reply(m.chat, 'Error while shortening the URL', m);
  }
};

handler.help = ['tinyurl'].map(v => v + ' <link>');
handler.tags = ['tools'];
handler.command = /^tinyurl$/i;
handler.limit = true;

module.exports = handler
async function shortlink(url) {
  const isUrl = /https?:\/\//.test(url);
  if (!isUrl) return '';
  
  try {
    const response = await axios.get('https://tinyurl.com/api-create.php?url=' + encodeURIComponent(url));
    return response.data;
  } catch (error) {
    console.error('Error fetching short URL:', error);
    return '';
  }
}