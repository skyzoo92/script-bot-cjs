const fetch = require('node-fetch');

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) throw `Use example ${usedPrefix}${command} https://www.mediafire.com/file/941xczxhn27qbby/GBWA_V12.25FF-By.SamMods-.apk/file`
    m.react("⏱️");

    const url = args[0];
    const apiUrl = `https://api.vreden.my.id/api/mediafiredl?url=${encodeURIComponent(url)}`;
    
    try {
        const response = await fetch(apiUrl);
        if (!response.ok) throw new Error(`Failed to fetch download link: ${response.statusText}`);
        
        const data = await response.json();
        if (data.status !== 200) throw new Error(`Failed to fetch download link: ${data.message}`);
        
        const { nama, size, mime, link } = data.result[0];
        
        const caption = `
*💌 Name:* ${nama}
*📊 Size:* ${size}
`.trim();
        
        await m.reply(caption);
        await conn.sendMessage(m.chat, { 
      document: { url: link }, 
      mimetype: 'application/zip',
      fileName: nama || 'mediafire_download.zip',
      caption: "",
    }, { quoted: m });
        m.react("");
    } catch (error) {
        console.error(error);
        m.react("❌");
        throw `Error: ${error.message}`;
    }
};

handler.help = ['mediafire'].map(v => v + ' <url>');
handler.tags = ['downloader'];
handler.command = /^(mediafire|mf)$/i;
handler.limit = 4
module.exports = handler