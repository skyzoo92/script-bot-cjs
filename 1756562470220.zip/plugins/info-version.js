const fs = require('fs');
let handler = async (m, { conn }) => {
  conn.reply(m.chat, `${staff.namebot} ᴠᴇʀsɪᴏɴ: *${global.info.version}*`, m, {
    contextInfo: {
      externalAdReply: {
        body: `🫧 ʀᴀᴘᴛʜᴀʟɪᴀ ʙᴏᴛ ᴠᴇʀsɪᴏɴ ${global.info.version}`,
        thumbnailUrl: `${logo.thumb}`,
        sourceUrl: link.saluran,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
};

handler.command = ['version','versi'];
handler.help = ['version'];
handler.tags = ['info'];

module.exports = handler