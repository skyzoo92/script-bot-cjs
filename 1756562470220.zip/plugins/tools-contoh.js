let handler = async (m, { conn }) => {
m.reply(`let handler = async (m, { conn }) => {\n};\n\nhandler.help = ['help']\nhandler.command = /^(command)$/i;\nhandler.tags = ['tag'];\n\nmodule.exports  = handler;`)
};

handler.help = ['contoh']
handler.command = /^(contoh)$/i;
handler.tags = ['tools'];

module.exports = handler;