let isAutoResetEnabled = false; 
let autoResetTimeout = null; 
let resetHour = 0; // default jam 00
let resetMinute = 0; // default menit 00

let handler = async (m, { conn, args, command }) => {
    let lim = 1000;
    let comlim = 100;

    if (args.length === 0) {
        return conn.reply(
            m.chat,
            `Gunakan *on* atau *off*.\n\nContoh:\n- *.${command} on* → reset otomatis setiap jam 00:00\n- *.${command} on 06:30* → reset otomatis setiap jam 06:30\n- *.${command} off* → menonaktifkan reset otomatis`,
            null
        );
    }

    if (args[0] === 'on') {
        if (isAutoResetEnabled) {
            return conn.reply(m.chat, `*Reset limit otomatis sudah aktif pada ${pad(resetHour)}:${pad(resetMinute)}!*`, null);
        }

        // cek kalau ada argumen jam
        if (args[1]) {
            let [h, mnt] = args[1].split(':').map(Number);
            if (isNaN(h) || isNaN(mnt) || h < 0 || h > 23 || mnt < 0 || mnt > 59) {
                return conn.reply(m.chat, `*Format jam salah!* Gunakan format HH:MM (contoh: 06:30)`, null);
            }
            resetHour = h;
            resetMinute = mnt;
        } else {
            resetHour = 0;
            resetMinute = 0;
        }

        isAutoResetEnabled = true;
        scheduleDailyReset(conn, lim, comlim);
        conn.reply(m.chat, `*Reset limit otomatis akan dijalankan setiap jam ${pad(resetHour)}:${pad(resetMinute)}.*`, null);

    } else if (args[0] === 'off') {
        if (!isAutoResetEnabled) {
            return conn.reply(m.chat, `*Reset limit otomatis sudah nonaktif!*`, null);
        }
        isAutoResetEnabled = false;
        cancelScheduledReset(); 
        conn.reply(m.chat, `*Reset limit otomatis dinonaktifkan.*`, null);

    } else {
        return conn.reply(
            m.chat,
            `*Argumen tidak valid!*\nHarap gunakan 'on' atau 'off'.\n\nContoh penggunaan:\n- *.${command} on*\n- *.${command} on 06:30*\n- *.${command} off*`,
            null
        );
    }
};

function resetLimit(conn, lim, comlim) {
    let list = Object.entries(global.db.data.users);
    list.forEach(([user, data]) => {
        data.limit = lim;
        data.commandLimit = comlim;
    });

    if (global.staff?.idgrup) {
        conn.reply(global.staff.idgrup, `*Limit berhasil direset ${lim} / user*`, null);
    } else {
        console.log(`Limit berhasil direset ${lim} / user`);
    }
}

function getTimeUntilTarget(hour, minute) {
    let now = new Date();
    let target = new Date(now);
    target.setHours(hour, minute, 0, 0);

    if (target <= now) {
        target.setDate(target.getDate() + 1); // besok kalau sudah lewat
    }
    return target - now;
}

function scheduleDailyReset(conn, lim, comlim) {
    let timeUntilTarget = getTimeUntilTarget(resetHour, resetMinute);

    autoResetTimeout = setTimeout(() => {
        if (isAutoResetEnabled) {
            console.log(`Mereset limit pengguna menjadi ${lim}`);
            resetLimit(conn, lim, comlim); 
            scheduleDailyReset(conn, lim, comlim); 
        }
    }, timeUntilTarget); 
}

function cancelScheduledReset() {
    if (autoResetTimeout) {
        clearTimeout(autoResetTimeout); 
        autoResetTimeout = null;
    }
}

function pad(num) {
    return String(num).padStart(2, '0');
}

handler.help = ['resetautolimit on/off [HH:MM]'];
handler.tags = ['owner'];
handler.command = /^(resetautolimit)$/i;
handler.owner = true;

module.exports = handler;