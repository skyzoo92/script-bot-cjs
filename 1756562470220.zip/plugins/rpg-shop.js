const items = {
    buy: {
        limit: {
            exp: 999
        },
        potion: {
            money: 1250
        },
        aqua: {
           money: 500
        },
        trash: {
            money: 40
        },
        wood: {
            money: 700
        },
        rock: {
            money: 850
        },
        string: {
            money: 400
        },
        iron: { 
        	money: 3000
        },
        diamond: {
            money: 7500
        },
        emerald: {
            money: 8500
        },
        gold: {
            money: 3500
        },
        coal: {
            money: 1500
        },
        common: {
            money: 200
        },
        uncommon: {
            money: 2000
        },
        mythic: {
            money: 25000
        },
        legendary: {
            money: 75000
        },
        foodpet: {
            money: 3500
        },
        Fox: {
            money: 40000
        },
        naga: {
            money: 120000
        },
        pet: {
            money: 120000
        },
        anggur: {
            money: 2000
        },
        apel: {
            money: 2000
        },
        batu: {
            money: 2000
        },
        berlian: {
            money: 2000
        },
        bibitanggur: {
            money: 2000
        },
        bibitapel: {
            money: 2000
        },
        bibitjeruk: {
            money: 2000
        },
        bibitmangga: {
            money: 2000
        },
        bibitpisang: {
            money: 2000
        },
        botol: {
            money: 2000
        },
        centaur: {
            money: 2000
        },
        eleksirb: {
            money: 2000
        },
        emasbatang: {
            money: 2000
        },
        emasbiasa: {
            money: 2000
        },
        exp: {
            money: 2000
        },
        gardenboc: {
            money: 2000
        },
        gardenboxs: {
            money: 2000
        },
        griffin: {
            money: 2000
        },
        healtmonster: {
            money: 2000
        },
        jeruk: {
            money: 2000
        },
        kaleng: {
            money: 2000
        },
        kardus: {
            money: 2000
        },
        kayu: {
            money: 2000
        },
        ketake: {
            money: 2000
        },
        koinexpg: {
            money: 2000
        },
        kucing: {
            money: 2000
        },
        kuda: {
            money: 2000
        },
        kyubi: {
            money: 2000
        },
        makanancentaur: {
            money: 2000
        },
        makanangriffin: {
            money: 2000
        },
        makanankyubi: {
            money: 2000
        },
        makanannaga: {
            money: 2000
        },
        makananpet: {
            money: 2000
        },
        makananphonix: {
            money: 2000
        },
        mangga: {
            money: 2000
        },
        pancingan: {
            money: 2000
        },
        phonix: {
            money: 2000
        },
        pisang: {
            money: 2000
        },
        rubah: {
            money: 2000
        },
        sampah: {
            money: 2000
        },
        serigala: {
            money: 2000
        },
        sword: {
            money: 2000
        },
        tiketcoin: {
            money: 2000
        },
        umpan: {
            money: 2000
        }
    },
    sell: {
        limit: {
            exp: 999
        },
        potion: {
            money: 1250
        },
        aqua: {
           money: 500
        },
        trash: {
            money: 40
        },
        wood: {
            money: 700
        },
        rock: {
            money: 850
        },
        string: {
            money: 400
        },
        iron: { 
        	money: 3000
        },
        diamond: {
            money: 7500
        },
        emerald: {
            money: 8500
        },
        gold: {
            money: 3500
        },
        coal: {
            money: 1500
        },
        common: {
            money: 200
        },
        uncommon: {
            money: 2000
        },
        mythic: {
            money: 25000
        },
        legendary: {
            money: 75000
        },
        foodpet: {
            money: 3500
        },
        Fox: {
            money: 40000
        },
        naga: {
            money: 120000
        },
        pet: {
            money: 120000
        },
        anggur: {
            money: 2000
        },
        apel: {
            money: 2000
        },
        batu: {
            money: 2000
        },
        berlian: {
            money: 2000
        },
        bibitanggur: {
            money: 2000
        },
        bibitapel: {
            money: 2000
        },
        bibitjeruk: {
            money: 2000
        },
        bibitmangga: {
            money: 2000
        },
        bibitpisang: {
            money: 2000
        },
        botol: {
            money: 2000
        },
        centaur: {
            money: 2000
        },
        eleksirb: {
            money: 2000
        },
        emasbatang: {
            money: 2000
        },
        emasbiasa: {
            money: 2000
        },
        exp: {
            money: 2000
        },
        gardenboc: {
            money: 2000
        },
        gardenboxs: {
            money: 2000
        },
        griffin: {
            money: 2000
        },
        healtmonster: {
            money: 2000
        },
        jeruk: {
            money: 2000
        },
        kaleng: {
            money: 2000
        },
        kardus: {
            money: 2000
        },
        kayu: {
            money: 2000
        },
        ketake: {
            money: 2000
        },
        koinexpg: {
            money: 2000
        },
        kucing: {
            money: 2000
        },
        kuda: {
            money: 2000
        },
        kyubi: {
            money: 2000
        },
        makanancentaur: {
            money: 2000
        },
        makanangriffin: {
            money: 2000
        },
        makanankyubi: {
            money: 2000
        },
        makanannaga: {
            money: 2000
        },
        makananpet: {
            money: 2000
        },
        makananphonix: {
            money: 2000
        },
        mangga: {
            money: 2000
        },
        pancingan: {
            money: 2000
        },
        phonix: {
            money: 2000
        },
        pisang: {
            money: 2000
        },
        rubah: {
            money: 2000
        },
        sampah: {
            money: 2000
        },
        serigala: {
            money: 2000
        },
        sword: {
            money: 2000
        },
        tiketcoin: {
            money: 2000
        },
        umpan: {
            money: 2000
        }
    }
}

let handler = async (m, { conn, command, args }) => {
    let user = global.db.data.users[m.sender]
    if (!user) return m.reply('User tidak ditemukan.')

    let [name, jumlah] = args
    if (!name) return m.reply(`Masukkan nama item!\nContoh: .${command} kayu 2`)
    jumlah = jumlah ? parseInt(jumlah) : 1
    if (isNaN(jumlah) || jumlah < 1) return m.reply('Jumlah harus berupa angka yang valid!')

    name = name.toLowerCase()

    switch (command) {
        case 'buy':
            if (!items.buy[name]) return m.reply('Item tidak tersedia untuk dibeli.')
            let harga = items.buy[name].money * jumlah
            if (user.money < harga) return m.reply(`Uang kamu kurang!\nHarga: ${harga}, Uang kamu: ${user.money}`)
            user.money -= harga
            user[name] = (user[name] || 0) + jumlah
            m.reply(`Berhasil membeli ${jumlah} ${name}\nSisa uangmu: ${user.money}`)
            break
        case 'sell':
            if (!items.sell[name]) return m.reply('Item tidak bisa dijual.')
            if (!user[name] || user[name] < jumlah) return m.reply(`Kamu tidak punya cukup ${name} untuk dijual.`)
            let hargaJual = items.sell[name].money * jumlah
            user[name] -= jumlah
            user.money += hargaJual
            m.reply(`Berhasil menjual ${jumlah} ${name}\nUangmu sekarang: ${user.money}`)
            break
        default:
            m.reply('Perintah tidak dikenal.')
    }
}

handler.help = ['buy [item] [jumlah]', 'sell [item] [jumlah]']
handler.command = /^(buy|sell)$/i
handler.tags = ['rpg']

module.exports = handler