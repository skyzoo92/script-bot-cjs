let handler = async (m, { conn, isROwner, usedPrefix, command, text }) => {
    if (!isROwner) return;
    if (!text) throw `uhm.. where is the text?\n\nExample:\n${usedPrefix + command} ytmp4`;

    let matches = [];

    for (let file in features) {
        let plugin = features[file];
        let fileName = file.replace('.js', '').toLowerCase();
        let isMatch = false;

        // Cek apakah nama file mengandung teks yang dicari
        if (fileName.includes(text.toLowerCase())) {
            isMatch = true;
        }

        // Cek apakah ada handler.command dalam plugin
        if (plugin.handler?.command) {
            let cmd = plugin.handler.command;

            if (cmd instanceof RegExp) {
                // Jika command berbentuk regex, cek apakah teks sesuai
                if (cmd.test(text.toLowerCase())) {
                    isMatch = true;
                }
            } else if (Array.isArray(cmd)) {
                // Jika command berbentuk array, cek apakah salah satu cocok
                if (cmd.some(c => c.toLowerCase().includes(text.toLowerCase()))) {
                    isMatch = true;
                }
            } else if (typeof cmd === 'string') {
                // Jika command adalah string, cek langsung
                if (cmd.toLowerCase().includes(text.toLowerCase())) {
                    isMatch = true;
                }
            }
        }

        if (isMatch) matches.push(fileName);
    }

    if (matches.length === 0) {
        return m.reply(`*🗃️ NOT FOUND!*\nTidak ada plugin yang cocok dengan *${text}*`);
    }

    m.reply(`*🔍 Ditemukan ${matches.length} Plugin*\n\n` + matches.map((v, i) => `${i + 1}. ` + v).join`\n`);
}

handler.help = ['cariplugins'].map(a => a + " *nama file atau command*");
handler.tags = ['owner'];
handler.command = /^(cariplugins|searchplugin|cplug|cp)$/i;
handler.rowner = true;

module.exports = handler;