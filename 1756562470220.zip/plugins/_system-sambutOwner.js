async function before(m, { conn, participants }) {
    if (!conn.time_join) {
        conn.time_join = {
            join: false,
            time: 0,
        };
    }

    const currentTime = Math.floor(Date.now() / 1000);
    if (!m.isGroup || conn.time_join.time > currentTime) {
        console.log("Not a group message or still in cooldown");
        return;
    }

    const isOwners = global.db.data.users[m.sender]?.owner;
    let messageText = "";
    let mentionedUsers = participants.map((u) => u.id).filter((v) => v !== conn.user.jid);

    let parti = await conn.groupMetadata(m.chat);
    let rendem = parti.participants[Math.floor(Math.random() * parti.participants.length)];

    switch (m.sender) {
        case staff.nomorown + "@s.whatsapp.net":
            messageText = "*Selamat Datang Kembali Ke Obrolan, Sayang kuh >//<!*";
            break;
        default:
            if (isOwners) {
                messageText = "Selamat datang, Owner ku !";
            }
            break;
    }

    if (messageText) {
        await conn.sendMessage(
            m.chat,
            { text: messageText },
            {
                quoted: m,
                mentions: mentionedUsers,
            }
        );
        conn.time_join = {
            join: true,
            time: currentTime + 300000, // cooldown 5 menit
        };
    } else {
        console.log("No message to send");
    }
}

module.exports = { before }