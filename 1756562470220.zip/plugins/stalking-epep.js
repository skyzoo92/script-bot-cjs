let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return m.reply(`• *Example :* ${usedPrefix + command} 12345678`);

  try {
    let res = await fetch(`https://api.fasturl.link/stalk/freefire?uid=${text}&region=id&media=true`);
    let json = await res.json();

    if (!json.status) return m.reply("❌ Data tidak ditemukan.");

    let result = json.result;

    // Mapping data
    let account = {
      name: result.accountInfo.name || "-",
      id: result.accountInfo.userId || "-",
      level: result.accountInfo.level || "-",
      xp: result.accountInfo.exp || "-",
      region: result.accountInfo.region || "-",
      like: result.accountInfo.likes || "-",
      bio: result.socialInfo?.signature || "-",
      create_time: result.accountInfo.createTimeDate || "-",
      last_login: result.accountInfo.lastLoginDate || "-",
      honor_score: result.creditScoreInfo?.creditScore || "-",
      booyah_pass: result.accountInfo.bpId ? true : false,
      booyah_pass_badge: result.accountInfo.bpBadges || "-",
      BR_points: result.accountInfo.brRankPoint || "-",
      CS_points: result.accountInfo.csRankPoint || "-"
    };

    let pet = {
      name: result.petInfo?.name || "-",
      level: result.petInfo?.level || "-",
      xp: result.petInfo?.exp || "-"
    };

    let guild = {
      name: result.guildInfo?.name || "-",
      id: result.guildInfo?.id || "-",
      level: result.guildInfo?.level || "-",
      member: result.guildInfo?.memberCount || "-",
      capacity: result.guildInfo?.capacity || "-"
    };

    let textResult = `
━━━━━━━━━━━━━━━━━━━━━━━
🎮 *ACCOUNT INFORMATION*
━━━━━━━━━━━━━━━━━━━━━━━
👤 *Nickname*: ${account.name}
🆔 *Account ID*: ${account.id}
⭐ *Level*: ${account.level}
🎯 *XP*: ${account.xp}
🌍 *Region*: ${account.region}
👍 *Likes*: ${account.like}
📝 *Bio*: ${account.bio}
🕒 *Account Created*: ${account.create_time}
🕒 *Last Login*: ${account.last_login}
🏆 *Honor Score*: ${account.honor_score}
💎 *Booyah Pass*: ${account.booyah_pass ? "Yes" : "No"}
🎖 *Booyah Pass Badge*: ${account.booyah_pass_badge}
🔥 *BR Rank Points*: ${account.BR_points}
💥 *CS Rank Points*: ${account.CS_points}

━━━━━━━━━━━━━━━━━━━━━━━
🐾 *PET INFORMATION*
━━━━━━━━━━━━━━━━━━━━━━━
🐕 *Name*: ${pet.name}
🦴 *Level*: ${pet.level}
🎯 *XP*: ${pet.xp}

━━━━━━━━━━━━━━━━━━━━━━━
🏰 *GUILD INFORMATION*
━━━━━━━━━━━━━━━━━━━━━━━
👑 *Guild Name*: ${guild.name}
🆔 *Guild ID*: ${guild.id}
📈 *Level*: ${guild.level}
👥 *Members*: ${guild.member}/${guild.capacity}
━━━━━━━━━━━━━━━━━━━━━━━
`.trim();

    m.reply(textResult);
  } catch (e) {
    console.log(e);
    m.reply("❌ Terjadi kesalahan pada server.");
  }
};

handler.help = ['ffstalk *<uid>*'];
handler.tags = ['stalking'];
handler.command = /^ffstalk$/i;

module.exports = handler;