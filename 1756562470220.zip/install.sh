pkg update && pkg upgrade
pkg install ffmpeg 
pkg install imagemagick 
npm start

